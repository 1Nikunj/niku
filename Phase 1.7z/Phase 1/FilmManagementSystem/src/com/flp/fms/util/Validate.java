package com.flp.fms.util;

import java.util.Iterator;
import java.util.List;

import com.flp.fms.domain.Language;

public class Validate {
	
	//validating the data
	
	public static boolean isValidTitle(String title){
		return title.matches("[a-zA-Z0-9., !]+");
		
	}
	public static boolean isValidDate(String year){
		return year.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|july|aug|sep|oct|nov|dec)-[12][890][0-9][0-9]");
	}
	public static boolean isValidLength(int length)
	{
		if(length>0 && length<=1000)
			return true;
		else return false;
	}
	public static boolean isValidRating(int rate)
	{
		if(rate>=1 && rate<=5)
			return true;
		else return false;
	}
	public static boolean isValidReplacementCost(double replacementcost)
	{
		if(replacementcost>=0)
			return true;
		else return false;
	}
	public static boolean checkDuplicateLanguage(List<Language> languages,Language language)
	{
		boolean flag=false;
		Iterator<Language> itr=languages.iterator();
		if(languages.isEmpty())
		{

			flag=false;
		}else{
			while(itr.hasNext()){
				Language language2=itr.next();
				if(language.equals(language2))
				{
					flag=true;
					break;
				}
			}
		
	}return flag;
}}
