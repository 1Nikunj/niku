package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.IActorService;

public class ActorDaoImplForList implements IActorDao{
	//Inserting the actor details 
	@Override
	public Set<Actor> getActors() {
		Set <Actor> actors=new HashSet<>();
		actors.add(new Actor(1001,"Sharukh","Khan"));
		actors.add(new Actor(1002,"Mohan","Lal"));
		actors.add(new Actor(1003,"Rajanikandh",""));
		actors.add(new Actor(1004,"Nivin","Pauly"));
		actors.add(new Actor(1005,"Deepika","Padukhone"));
		actors.add(new Actor(1006,"Asin","Thottunkal"));
		return actors;
	} 
	
}
