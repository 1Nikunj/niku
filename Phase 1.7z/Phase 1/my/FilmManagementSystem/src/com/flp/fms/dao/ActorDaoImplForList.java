package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao {
public Set<Actor> getActors(){
	
	
	
	Set<Actor> actors=new HashSet<>();
	actors.add(new Actor(101,"Tom","Jerry",0));
	actors.add(new Actor(102,"Sharuk","Khan",0));
	actors.add(new Actor(103,"Kamal","Kashan",0));
	actors.add(new Actor(104,"Jack","Thomson",0));
	actors.add(new Actor(105,"Annie","Jessie",0));
	return actors;
}
}
