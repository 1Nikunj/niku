package com.flp.fms.dao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
public class FilmDaoImplForList implements IFilmDao {

	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	@Override
	public List<Category> getCategory() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1, "Drama", 0));
		categories.add(new Category(2, "Comedy",0));
		categories.add(new Category(3, "Horror",0));
		categories.add(new Category(4, "Scientific",0));
		categories.add(new Category(5, "Romantic",0));
		categories.add(new Category(6, "Action",0));
		
		
		return categories;
	}

	@Override
	public List<Language> getLanguage() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English",0));
		languages.add(new Language(2, "Hindi",0));
		languages.add(new Language(3, "Telegu",0));
		languages.add(new Language(4, "Marati",0));
		languages.add(new Language(5, "Kananta",0));
		languages.add(new Language(6, "Tamil",0));
		languages.add(new Language(7, "Malayalam",0));
		return languages;
	}
	//CURD Operation
		@Override
		public void addFilm(Film film) {
			film_Repository.put(film.getFim_id(), film);
			
		}


		@Override
		public Map<Integer, Film> getAllFilms() {
			
			return film_Repository;
		}
}