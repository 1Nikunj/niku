package com.flp.fms.view;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
//import java.sql.Date;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
	//Return fully qualified film object
	public Film addFilm(List<Language> languages,List<Category> categories,Set<Actor>actors){
		//Create Film Object
		Film film=new Film();
		boolean flag=true;
		
		//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		
		//Release date validation
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		do{
			
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setRelease_Date(release_Date);
		
		
		//Rental date validation
		String rentalDate=null;
		boolean rdate_flag=false;
		Date rental_Date=null;
		do{
			
			do{
				System.out.println("Enter Rental Date:");
				rentalDate=sc.next();
				 rdate_flag=Validate.isValidDate(rentalDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			Date today=new Date();
			rental_Date=new Date(rentalDate);
			if(rental_Date.after(release_Date))
				rdate_flag=true;
		
			if(!rdate_flag)
				System.out.println("Invalid Date! Date should be Future date!");
		}while(!rdate_flag);
		film.setRental_Duration(rental_Date);
		
		
		//Length Validation
		int len=0;
		int lflag=0;
		do{
			System.out.println("Enter the Length of Film:");
			len=sc.nextInt();
			lflag=Validate.isValidLength(len);
			if(lflag==1)
				film.setLenght(len);
			if(lflag==0)
				System.out.println("Invalid Length.Please enter the valid Length.");
		}while(!flag);
		
		//Replacement cost Validation
		double cost=0.0;
		int cflag=0;
		do{
			System.out.println("Enter the Replacement Cost:");
			cost=sc.nextDouble();
			cflag=Validate.isValidCost(cost);
			if(cflag==1)
				film.setReplacement_Cost(cost);
			else
			System.out.println("Invalid Replacement cost.Please enter number greater then zero.");
			}while(!flag);
		//To get Description about Film
			String desc;
			System.out.println("Enter the Description of Film:");
			desc=sc.next();
			film.setFilm_Description(desc); 
			//To get Special features
			String feature;
			System.out.println("Enter the Special feature:");
			feature=sc.next();
			film.setSpecial_features(feature); 
			
			
			//Choose original Language 
			System.out.println("Choose Original Language:");
			Language language= addLanguage(languages);
			film.setOriginal_Lang(language);
			
			
			//Add All Languages
			List<Language> languages2=new ArrayList<>();
			String choice;
			boolean flag_lang;
			do{
				System.out.println("Choose all languages for the film:");
				Language language1=addLanguage(languages);
				flag_lang=Validate.checkDuplicateLanguage(languages2,language1);
				if(!flag_lang)
					languages2.add(language1);
				else
					System.out.println("Language Already exists.Please try other.");
				System.out.println("Wish to add more Language?[y/n]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			film.setLanguage(languages2);
			
			
			
			
			//Add All actors
			Set<Actor> actors2=new HashSet<>();
			do{
				System.out.println("Choose All actors for the film:");
				Actor actor=addActor(actors);
				System.out.println("wishto add more actors?[Y/N]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			film.setActor(actors2);
			
			
			//Choose Film Category 
			System.out.println("Choose Category:");
			Category category= selectCategory(categories);
			film.setCategory(category);
			
			//Rating for movie
			int rate=0;
			do{
			System.out.println("Enter Film Rating");
			rate=sc.nextInt();
			flag=Validate.isValidRating(rate);
				if(!flag)
					System.out.println("Invalid Rating. Please Enter Valid Rating!");
			}while(!flag);
			film.setRating(rate);
			
		return film;
	}
//Choose valid language object from the list:

public Language addLanguage(List<Language>  languages){
	
	Language sel_language=null;
	boolean flag;
	do{	
		//Print Language Details
		for(Language language:languages)
			System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
		
		System.out.println("Choose the Language:");
		int option=sc.nextInt();
		
		flag=false;
		
		//Check the Language Object
		for(Language language: languages)
		{
			if(option==language.getLanguage_Id())
			{
				sel_language=language;
				flag=true;
				break;
			}
		}
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid Language Id");
	}while(!flag);	
	
	return sel_language;

}
//Choose valid category
public Category selectCategory(List<Category>  categories){

Category sel_category=null;
boolean flag;
do{	
	//Print Category Details
	for(Category category:categories)
		System.out.println(category.getCategory_Id() + "\t" + category.getCategory_Name());
	
	System.out.println("Choose the category:");
	int option=sc.nextInt();
	
	flag=false;
	
	//Check the Category Object
	for(Category category:categories)
	{
		if(option==category.getCategory_Id())
		{
			sel_category= category;
			flag=true;
			break;
		}
	}
	
	//Print Error Message
	if(!flag)
		System.out.println("Please select valid category Id");
}while(!flag);	

return sel_category;
}
//Choose Valid Actor Object from the list of Actors
	public Actor addActor(Set<Actor> actors){
		
		Actor sel_actor=null;
		boolean flag=false;
		
		do{	
		for(Actor actor:actors)
			System.out.println(actor.getActor_id() + "\t" + actor.getFirstName() + "\t" + actor.getLastName());
		
		System.out.println("Choose the Actor:");
		int option=sc.nextInt();
		
		flag=false;
		
		//Check the Actor Object
		for(Actor actor: actors)
		{
			if(option==actor.getActor_id())
			{
				sel_actor=actor;
				flag=true;
				break;
			}
		}
			
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid Actor Id");
		}while(!flag);	
		
		return sel_actor;
	}
public void getAllFilm(Collection<Film> lst) {
		
		
		
		for(Film film:lst){
			String languages="";
			for(Language language:film.getLanguage())
				languages=languages+language.getLanguage_Name()+",";
			
			System.out.println(film.getFim_id() + "\t" +
					film.getTitle() + "\t"+
					film.getRelease_Date() + "\t"+
					film.getRental_Duration()+"\t"+
					film.getReplacement_Cost()+"\t"+
					film.getRating()+"\t"+languages);
			}
		
	}
	
	
public void searchFilmById(Collection<Film> lst){
	
	System.out.println("Please Enter Film Id you want to Search");
	int f_id=sc.nextInt();
	for(Film film:lst){
		if(f_id==film.getFim_id())
		{
			System.out.println(film);
		}
		else
		System.out.println("Not Found.Please Enter Valid ID!!");
	
	
}
	}
public void searchFilmByTitle(Collection<Film> lst){
	
	System.out.println("Please Enter Film Title you want to Search");
	String f_title=sc.next();
	for(Film film:lst){
		if(f_title.equals(film.getTitle()))
		{
			System.out.println(film);
		}
		else
		System.out.println("Not Found.Please Enter Valid Title!!");
	
	
}
	}
public void searchFilmByRating(Collection<Film> lst){
	
	System.out.println("Please Enter Film Rating you want to Search");
	int f_rate=sc.nextInt();
	for(Film film:lst){
		if(f_rate==film.getRating())
		{
			System.out.println(film);
		}
		else
		System.out.println("Not Found.Please Enter Valid Title!!");
	
	
}
	}
public void deleteFilm(Collection<Film> lst){
	System.out.println("Please Enter Film Id of Film which you want to remove.");
	int f_id=sc.nextInt();
	boolean flag=false;
	for(Film film:lst){
		if(f_id==film.getFim_id())
		{
			lst.remove(film);
			System.out.println("Film"+f_id+"Removed");
			System.out.println(lst);
		}
		if(flag=false){
		System.out.println("Not Found");
		}
	
}

}
}
