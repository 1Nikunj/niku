package com.flp.fms.domain;

public class Actor {
	//Private Fields
private int actor_id;
private String firstName;
private String lastName;
private int film_Id;
//Default constructor
public Actor() {
}
//Parameterized Constructor
public Actor(int actor_id, String firstName, String lastName, int film_Id) {
	super();
	this.actor_id = actor_id;
	this.firstName = firstName;
	this.lastName = lastName;
	this.film_Id = film_Id;
}
//Setters and Getters
public int getActor_id() {
	return actor_id;
}

public void setActor_id(int actor_id) {
	this.actor_id = actor_id;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public int getFilm_Id() {
	return film_Id;
}

public void setFilm_Id(int film_Id) {
	this.film_Id = film_Id;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + actor_id;
	result = prime * result + film_Id;
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Actor other = (Actor) obj;
	if (actor_id != other.actor_id)
		return false;
	if (film_Id != other.film_Id)
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	return true;
}
@Override
public String toString() {
	return "Actor [actor_id=" + actor_id + ", firstName=" + firstName + ", lastName=" + lastName + ", film_Id="
			+ film_Id + "]";
}

}
