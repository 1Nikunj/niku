package com.flp.fms.domain;

public class Category {
	//Private fields
private int category_Id;
private String Category_Name;
private int film_id;
//No Arguments constructor
public Category() {
}
//Parameterized constructor
public Category(int category_Id, String category_Name, int film_id) {
	super();
	this.category_Id = category_Id;
	Category_Name = category_Name;
	this.film_id = film_id;
}
//Setters and Getters
public int getCategory_Id() {
	return category_Id;
}
public void setCategory_Id(int category_Id) {
	this.category_Id = category_Id;
}
public String getCategory_Name() {
	return Category_Name;
}
public void setCategory_Name(String category_Name) {
	Category_Name = category_Name;
}
public int getFilm_id() {
	return film_id;
}
public void setFilm_id(int film_id) {
	this.film_id = film_id;
}
@Override
public String toString() {
	return "Category [category_Id=" + category_Id + ", Category_Name=" + Category_Name + ", film_id=" + film_id + "]";
}
}
