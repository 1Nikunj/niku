package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/* ======================= Servlet for showing the Delete Film Table to the User ==================== */

public class DeleteFilmServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


/*======= Creating Object for the Film Service Layer and Film Class to call the methods ============= */

		IFilmService filmService=new FilmServiceImpl();
		ArrayList<Film> films=filmService.getAllFilms();

		PrintWriter out=response.getWriter();	
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
				+ "</head>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<center><table></center>"
				+ "<tr>"
				+ "<th> Film Id </th>"
				+ "<th> Name </th>"
				+ "<th>	Description	</th>"
				+ "<th>	Release Year	</th>"
				+ "<th>	Rental Duration	</th>"
				+ "<th>	Original Language	</th>"
				+ "<th> Other Lanugages"
				+ "<th> Actors"
				+ "<th>	Length	</th>"
				+ "<th>	Replacement Cost	</th>"
				+ "<th>	Special Feature </th>"
				+ "<th>	Category	</th>"
				+ "</tr>");

/* ===================== Iterator to print the values passed via the films object ===================*/

		for(Film film:films){
			out.println("<tr>");
			out.println("<td>"+film.getFilm_Id()+"</td>");
			out.println("<td>"+film.getTitle()+"</td>");
			out.println("<td>"+film.getDescription()+"</td>");
			out.println("<td>"+film.getReleaseYear()+"</td>");
			out.println("<td>"+film.getRentalDuration()+"</td>");
			out.println("<td>"+film.getOriginalLanguage().getLanguage_Name()+"</td>");

			List<Language>langs=new ArrayList<>();
			langs=film.getLanguages();

			out.println("<td>");
			for(Language lang:langs)
				out.println(lang.getLanguage_Name());
			out.println("</td>");

			List<Actor> actors = new ArrayList<>();
			actors=film.getActors();
			out.println("<td>");
			for(Actor act:actors)
				out.println(act.getActor_First_Name()+" "+act.getActor_Last_Name());
			out.println("</td>");
			out.println("<td>"+film.getLength()+"</td>");
			out.println("<td>"+film.getReplacementCost()+"</td>");
			out.println("<td>"+film.getSpecialFeatures()+"</td>");
			out.println("<td>"+film.getFilm_Category().getCategory_Name()+"</td>");

/* ==================== Redirecting to DeleteServlet via Film ID attribute  ========================*/

			out.println("<td><a href='DeleteServlet?filmid="+film.getFilm_Id()+"'>Delete</a></td>");
			out.println("</tr>");
		}
		
		out.println("</table></body>");
		out.println("</html>");

	}


}


