package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

/* ========== Servlet to display the form with filled-in fields so that user can edit ================== */

public class EditServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();

		FilmServiceImpl filmser=new FilmServiceImpl();
		ActorServiceImpl actorService=new ActorServiceImpl();

		List<Actor> actor=actorService.getActorList();
		List<Language> languages=filmser.getLanguages();
		List<Category> category=filmser.getCategory();


		int id=Integer.parseInt(request.getParameter("id"));

		Film film=filmser.getFilmByID(id);
		System.out.println(film);

		DateFormat df=new SimpleDateFormat("dd-MMM-yyyy");

		List<Actor> actFilm=film.getActors();
		List<Language>langFilm=film.getLanguages();

		out.print("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.print("<script type='text/javascript' src='script/validate.js'></script>"
				+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"			// JQuery for DatePicker (Problem with Year and Month)
				+ "<script type='text/javascript' src='script/jquery-1.8.3.js'></script>"
				+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.js'></script>"
				+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.min.js'></script>"
				+ "<script type='text/javascript' src='script/dateSelector.js'></script>");

		out.print("</head>");

		out.print("<html>");
		out.print("<body>");
		out.print("<form name='film' method='post' action='EditServlet2' onsubmit='validateForm()'>");  //Validate and submit the form after the users edits
		out.print("<h1 align='center'>Fill The Details of Film</h1>");
		out.println("<center> "
				+ "<center><table></center>"
				+ "<tr>"
				+ "<td><label>Film Title</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='title' value='"+film.getTitle()+"'>"
				+ "<div id='titleErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td><label>Description</label></td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='desc' cols='25'>"+film.getDescription()+"</textarea></td><"
				+ "/tr>");

		out.print("<tr>"
				+ "<td>Release Year</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='release'  id='relYear' value='"+df.format(film.getReleaseYear())+"' />"
				+ "</td>"
				+ "</tr>");

/* ==================================== To Edit Original Language (List) ================================ */
		
		out.print("<tr><td>Original Language</td><td>:</td>"
				+ "<td><select name='orgLang'>");
		for(Language lang:languages){
			if(lang.getLanguage_Name().equals(film.getOriginalLanguage().getLanguage_Name())){
				out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");

			}
			else
				out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
		}

		out.print("<tr>"
				+ "<td>Rental Duration</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='rentD'  id='rentalDur' value='"+df.format(film.getRentalDuration())+"' />"
				+ "</td>"
				+ "</tr>");

		out.print("<tr>"
				+ "<td>Length Of Film</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='length' size='20' value='"+film.getLength()+"'></td>"
				+ "</tr>");

		out.print("<tr>"
				+ "<td>Replacement Cost</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='cost' size='20' value='"+film.getReplacementCost()+"'></td>"
				+ "</tr>");

		out.print("<tr>"
				+ "<td>Ratings</td>"
				+ "<td>:</td>"
				+ "<td><select name='rating' onchange='return isratingSelected()'>");
		for(int i=0;i<=5;i++){
			if(i==film.getRatings()){
				out.print("<option value='"+i+"' selected>"+i+"</option>");
			}
			else
				out.print("<option value='"+i+"' >"+i+"</option>");
		}

		out.print( "</select></td>"
				+ "</tr>");

		out.print("</select></td></tr>");
		out.print("<tr>"
				+ "<td><label>Special Features:</td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='spec' cols='25'>"+film.getSpecialFeatures()+"</textarea></td>"
				+ "</tr>");




/* ==================================== To Edit Category (List) ================================ */
		
		out.print("<tr><td>Category</td><td>:</td>"
				+ "<td><select name='category'>"
				+ "<option value=''>Select category</option>");
		for(Category category1:category){
			if(category1.getCategory_Name().equals(film.getFilm_Category().getCategory_Name())){
				out.print("<option value='"+category1.getCategory_Id()+"' selected>"+category1.getCategory_Id()+" "+category1.getCategory_Name()+"</option>");
			}
			else
				out.print("<option value='"+category1.getCategory_Id()+"'>"+category1.getCategory_Id()+" "+category1.getCategory_Name()+"</option>");
		}
		out.print("</select></td></tr>");

/* ==================================== To Edit Actor (List) ================================ */
		
		out.print("<tr><td>Actor</td><td>:</td>"
				+ "<td><select name='actor' multiple=''>"
				+ "<option value''>Select actors</option>");
		boolean flag=false;
		int id1=0;

		for(Actor actor1:actor){
			for(Actor actt:actFilm){

				if(actor1.getActor_First_Name().equals(actt.getActor_First_Name()) && actor1.getActor_Last_Name().equals(actt.getActor_Last_Name())){
					flag=true;
					id1=actor1.getActor_Id();
				}
				
			}
			if(flag==true && id1==actor1.getActor_Id())
				out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_First_Name()+" "+actor1.getActor_Last_Name()+"</option>");
			else
				out.print("<option value='"+actor1.getActor_Id()+"' >"+actor1.getActor_Id()+" "+actor1.getActor_First_Name()+" "+actor1.getActor_Last_Name()+"</option>");

		}
		out.print("</select></td></tr>");


/* ==================================== To Edit Languages (List) ================================ */

		out.print("<tr><td>Other Language</td><td>:</td>"
				+ "<td><select name='othrlang' multiple='' class='ui fluid dropdown'>"
				+ "<option value=''>Select languages</option>");
		boolean flag1=false;
		int id2=0;
		for(Language lang:languages){

			for(Language lng:langFilm){

				if(lang.getLanguage_Name().equals(lng.getLanguage_Name())){
					flag1=true;
					id2=lang.getLanguage_Id();
				}

			}
			if(flag1==true && id2==lang.getLanguage_Id())
				out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
			else
				out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");


		}
		out.print("</select></td></tr>"
				+ "<tr><td><input type='hidden' name='film_id' value='"+id+"'");

		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit' class='myBtn'></td>"   
				+ "</tr>");





		out.print("</html");
	}

}
