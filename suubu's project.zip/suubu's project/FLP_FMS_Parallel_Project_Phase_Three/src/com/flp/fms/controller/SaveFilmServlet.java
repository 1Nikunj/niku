package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;


/* ===================== Servlet for Saving the User Interaction Form value =================== */

public class SaveFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService loginService=new FilmServiceImpl();
		
		Film film=new Film();
		Category cat=new Category();
		Actor actor=new Actor();
		Language lang=new Language(); 
		
	
		film.setTitle(request.getParameter("filmTitle"));
		film.setDescription(request.getParameter("filmDescription"));
		film.setLength(Integer.parseInt(request.getParameter("filmlength")));
		
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("originalLanguage")));
		film.setOriginalLanguage(lang);
		
		ArrayList<Language> languages=new ArrayList<>();
		String[] str=request.getParameterValues("otherLanguage");
		for(String str1:str){
			Language lang1=new Language(); 
			lang1.setLanguage_Id(Integer.parseInt(str1));
			languages.add(lang1);
		}
		film.setLanguages(languages);
		
		
		film.setRatings(Integer.parseInt(request.getParameter("frating")));
			
		film.setReleaseYear(new Date(request.getParameter("releaseYear")));
		
		film.setRentalDuration(new Date(request.getParameter("rentalDuration")));		// Setting the user-entered values to the film object in the database
		
		film.setReplacementCost(Double.parseDouble(request.getParameter("replacementcost")));
		
		film.setSpecialFeatures(request.getParameter("specialfeature"));
		
		List<Actor> actors=new ArrayList<>();
	
		String[] str3=request.getParameterValues("actor");
		for(String str1:str3){
			Actor actor1=new Actor(); 
			actor1.setActor_Id(Integer.parseInt(str1));
			actors.add(actor1);
		}
		film.setActors(actors);
		

		
		Category cat1=new Category();
		cat1.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setFilm_Category(cat1);
		
		
		loginService.addFilm(film);
		PrintWriter out=response.getWriter();		
		out.println("<html><body>");
		out.println("<h1>Film Details Added Successfully</h1>");
		out.println("</body></html>");
		
		
		
	}



}
