package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/* =================== Servlet for Deleting the film from database ===========================*/

public class DeleteServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		String film_Id=request.getParameter("filmid");  //Fetching the requested object using film id

		System.out.println(film_Id);

		IFilmService filmService=new FilmServiceImpl();

		boolean flag=filmService.deleteFilm(Integer.parseInt(film_Id));

		if(!flag) {
			request.getRequestDispatcher("DeleteFilmServlet").forward(request, response);
			
			PrintWriter out=response.getWriter();	
			out.println("<html><body>");
			out.println("<h1>Film  Deleted  Successfully</h1>");
			out.println("</body></html>");
		}

	}

}
