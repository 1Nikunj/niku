package com.flp.fms.controller;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;



public class SaveActorServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		Actor actor = new Actor();
		ActorServiceImpl actorservice = new ActorServiceImpl();
		actor.setActor_First_Name(request.getParameter("firstName"));			
		actor.setActor_Last_Name(request.getParameter("lastName"));
		
		actorservice.saveActor(actor);
		PrintWriter out=response.getWriter();		
		out.println("<html><body>");
		out.println("<h1>Actor Details Added Successfully</h1>");
		out.println("</body></html>");

	}

	}


