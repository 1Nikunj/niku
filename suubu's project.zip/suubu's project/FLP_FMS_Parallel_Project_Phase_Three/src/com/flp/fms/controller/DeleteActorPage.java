package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;

/* =========================== Servlet for Deleting Actor data from Database ================= */

public class DeleteActorPage extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		ActorServiceImpl actorservice = new ActorServiceImpl();
		List<Actor> actorList = actorservice.getActorList();
		
		
		PrintWriter out=response.getWriter();
		
	
		out.println("<html>");
		out.println("<head><center><h1> Actor Details </h1></center>"
				+ "<link rel='stylesheet' type='text/css' href='css/mystyles.css'></head>"
				+ "<body><center>"
				+ "<table border='2' align='center'>"
				+ "<tr>"				
				+ "<th>Actor Id</th>"
				+ "<th>Actor First Name</th>"
				+ "<th>Actor Last Name</th>"
				+ "<th>Delete Link</th>"
				+ "</tr>");
		
      
		
		for(Actor actor:actorList)
		{
			out.println("<tr>");
			out.println("<td>"+actor.getActor_Id()+"</td>");
			out.println("<td>"+actor.getActor_First_Name()+"</td>");
			out.println("<td>"+actor.getActor_Last_Name()+"</td>");
			out.println("<td><a href='DeleteActorList?actor_Id="+actor.getActor_Id()+"'>Delete</a></td>");

			
			out.println("</td>");
			out.println("</tr>");
		}

		out.println("</table></center></body>");		
		out.println("</html>");	

	}
	}

	

