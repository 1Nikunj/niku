package com.flp.fms.dao;

import java.util.List;
import com.flp.fms.domain.Actor;

public interface IActorDao {

	public List<Actor>addActor();

	public List<Actor> getActorList();
	
	public boolean deleteActor(int actorId);
	
	public int saveActor(Actor actor);
	
	
}
