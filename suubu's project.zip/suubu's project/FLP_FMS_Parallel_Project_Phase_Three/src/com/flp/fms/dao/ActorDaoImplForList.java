package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao{

	@Override
	public List<Actor> addActor() {
		
		return null;
	}


/* ================================= Database Connection using JDBC ========================== */
	
	public Connection  getConnection(){

		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Registered");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms", "root", "Pass1234");
			System.out.println("connection created");


		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return connection;
	} 


	@Override
	public List<Actor> getActorList() {
		List<Actor> actors=new ArrayList<>();

		FilmDaoImplForList filmDao=new FilmDaoImplForList();
		Connection con= filmDao.getConnection();

		String sql="select * from actors order by firstName ASC";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();

			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setActor_First_Name(rs.getString(2));
				actor.setActor_Last_Name(rs.getString(3));

				actors.add(actor);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return actors;


	}

/* ===================== Deleting Actor from the Database ====================================*/
	
	public boolean deleteActor(int actorId)
	{
		
		Connection con=getConnection();		
		boolean flag=false;

		String sql="delete from actors where actor_id =?";
		
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
		
			pst.setInt(1, actorId);			

			int count=pst.executeUpdate();			

			if(count>0)
				flag=true;
			con.close();
		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}	
		return flag;
		
		
	}
	
/*===================== Retrieving all actors from Database =========================== */


	public List<Actor> getAllActors() 
	{
		List<Actor> actorList=new ArrayList<>();

		String sql="SELECT * FROM actors ORDER BY firstname ASC ";
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();

			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setActor_First_Name(rs.getString(2));
				actor.setActor_Last_Name(rs.getString(3));
				//Adding Actor into List
				actorList.add(actor);
			}

			con.close();
		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}
		return actorList;
}

	/* =========================== Adding Actors to the Database==================================*/

	public int saveActor(Actor actor)
	{

		Connection con=getConnection();

		String sql="INSERT INTO actors (firstName,lastName)VALUES(?,?)";				

		int id = 0,count=0;
		try 
		{
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getActor_First_Name());
			pst.setString(2, actor.getActor_Last_Name());
			
			count=pst.executeUpdate();
			con.close();
		}
		catch(Exception e){}

		return count;
	}



}













