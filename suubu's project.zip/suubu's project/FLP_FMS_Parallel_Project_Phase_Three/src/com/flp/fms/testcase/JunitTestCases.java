package com.flp.fms.testcase;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class JunitTestCases {

	//Test Case to check if Lists return null value
	
	FilmDaoImplForList filmDao=new FilmDaoImplForList();
	ActorDaoImplForList actorDao=new ActorDaoImplForList();
	
	
	@Test
	public void testForLanguageList() {
		
		FilmDaoImplForList filmlist = new FilmDaoImplForList();
	
		assertNotEquals(filmlist.getLanguages(), null);

	}

	@Test
	public void testForCategoryList() {
		
		FilmDaoImplForList categorylist = new FilmDaoImplForList();
		
		assertNotEquals(categorylist.getCategory(), null);
		
	}
	
	@Test
	public void testGetAllFilms() {
		
		FilmDaoImplForList getallfilms = new FilmDaoImplForList();
		
		assertNotEquals(getallfilms.getAllFilms(), null);
	}
	
	

	//Updating a film
	
	@Test
	public void testUpdateFilm(){

		Film film=new Film();
		film.setFilm_Id(5);
		film.setTitle("The notebook");
		film.setDescription("aaaa");
		Date d=new Date("15-apr-2016");
		film.setReleaseYear(d);

		Language lang=new Language();
		lang.setLanguage_Id(1);
		film.setOriginalLanguage(lang);
		Date d1=new Date("13-may-2016");
		film.setRentalDuration(d1);
		film.setLength(11);
		film.setReplacementCost(1111);
		film.setRatings(2);
		film.setSpecialFeatures("asdfg");
		Category category=new Category();
		category.setCategory_Id(1);
		film.setFilm_Category(category);

		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
		langs.add(lang1);
		film.setLanguages(langs);

		List<Actor> actors=new ArrayList<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		Actor actor2=new Actor();
		actor2.setActor_Id(2);
		actors.add(actor1);
		actors.add(actor2);
		film.setActors(actors);

		assertEquals(1, filmDao.updateFilm(15, film));

	}

	// To check List of Languages
	
	@Test
	public void testGetLanguages(){


		List<Language>languages=new ArrayList<>();
		
		
		languages.add(new Language(1,"English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Malayalam"));
		languages.add(new Language(4, "Tamil"));
		
		
		assertNotEquals(languages, filmDao.getLanguages());

	}
	
	

}
