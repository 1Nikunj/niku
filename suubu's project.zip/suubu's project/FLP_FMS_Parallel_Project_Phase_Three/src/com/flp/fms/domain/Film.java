package com.flp.fms.domain;

import java.util.Date;
import java.util.List;
import java.util.Set;

public class Film {



	//private variables
	private int film_Id;
	private String title;
	private String description;
	private Date releaseYear;
	private List<Language> languages;
	private Language originalLanguage;
	private Date rentalDuration;
	private int length;
	private double replacementCost;
	private int ratings;
	private String specialFeatures;
	private List<Actor> actors;
	private Category category;

	//No argument Constructor
	public Film() {}




	//Constructor with Fields

	public Film(int film_Id, String title, String description, Date releaseYear, List<Language> languages,
			Language originalLanguage, Date rentalDuration, int length, double replacementCost, int ratings,
			String specialFeatures, List<Actor> actors, Category category) {
		super();
		this.film_Id = film_Id;
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.languages = languages;
		this.originalLanguage = originalLanguage;
		this.rentalDuration = rentalDuration;
		this.length = length;
		this.replacementCost = replacementCost;
		this.ratings = ratings;
		this.specialFeatures = specialFeatures;
		this.actors=actors;
		this.category = category;
	}


	//Getter and Setter methods
	
	public int getFilm_Id() {
		return film_Id;
	}

	public void setFilm_Id(int film_Id) {
		this.film_Id = film_Id;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public Date getReleaseYear() {
		return releaseYear;
	}



	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}



	public List<Language> getLanguages() {
		return languages;
	}



	public void setLanguages(List<Language> languages) {
		this.languages = languages;
	}



	public Language getOriginalLanguage() {
		return originalLanguage;
	}



	public void setOriginalLanguage(Language originalLanguage) {
		this.originalLanguage = originalLanguage;
	}



	public Date getRentalDuration() {
		return rentalDuration;
	}



	public void setRentalDuration(Date rentalDuration) {
		this.rentalDuration = rentalDuration;
	}



	public int getLength() {
		return length;
	}



	public void setLength(int length) {
		this.length = length;
	}



	public double getReplacementCost() {
		return replacementCost;
	}



	public void setReplacementCost(double replacementCost) {
		this.replacementCost = replacementCost;
	}



	public int getRatings() {
		return ratings;
	}



	public void setRatings(int ratings) {
		this.ratings = ratings;
	}



	public String getSpecialFeatures() {
		return specialFeatures;
	}



	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}



	public List<Actor> getActors() {
		return actors;
	}


	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}


	public Category getFilm_Category() {
		return category;
	}



	public void setFilm_Category(Category film_Category) {
		this.category = film_Category;
	}

	//public toString method
	@Override
	public String toString() {
		return "Film [film_Id=" + film_Id + ", title=" + title + ", description=" + description + ", releaseYear="
				+ releaseYear + ", languages=" + languages + ", originalLanguage=" + originalLanguage
				+ ", rentalDuration=" + rentalDuration + ", length=" + length + ", replacementCost=" + replacementCost
				+ ", ratings=" + ratings + ", specialFeatures=" + specialFeatures + ", actors=" + actors
				+ ", film_Category=" + category + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actors == null) ? 0 : actors.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Film other = (Film) obj;
		if (actors == null) {
			if (other.actors != null)
				return false;
		} else if (!actors.equals(other.actors))
			return false;
		return true;
	}

}
