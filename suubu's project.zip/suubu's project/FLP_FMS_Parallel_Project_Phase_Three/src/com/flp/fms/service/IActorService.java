package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorService {

	public List<Actor>addActor();

	public List<Actor> getActorList();
	
	public boolean deleteActor(int actorId);
	
	public List<Actor> getAllActors();
	
	public int saveActor(Actor actor);
	

}
