package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements  IActorService {

	ActorDaoImplForList actorDao=new ActorDaoImplForList();
	
	
	@Override
	public List<Actor> addActor() {

		
		return actorDao.addActor();
	}

	@Override
	public List<Actor> getActorList() {

		
		return actorDao.getActorList();
	}


	public boolean deleteActor(int actorId)
	{
		
		return actorDao.deleteActor(actorId);
	}

	
	public List<Actor> getAllActors()
	{
		
		return actorDao.getAllActors();
	}
	
	public int saveActor(Actor actor)
	{
		return actorDao.saveActor(actor);
	}
	
}

