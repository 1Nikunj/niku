package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;


import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService {

	IFilmDao filmDao=new FilmDaoImplForList();



	@Override
	public List<Language> getLanguages() {

		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getCategory() {

		return filmDao.getCategory();
	}

	@Override
	public void addFilm(Film film) {

		filmDao.addFilm(film);

	}

	@Override
	public ArrayList<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	@Override
	public boolean deleteFilm(int filmid) {
		
		return filmDao.deleteFilm(filmid);
	}

	@Override
	public List<Film> searchFilm(Film film) {

		return filmDao.searchFilm(film);
	}

	public Film getFilmByID(int id) {

		return filmDao.getFilmByID(id);
	}

	public int updateFilm(int id, Film film) {

		return filmDao.updateFilm(id, film);
	}


}
