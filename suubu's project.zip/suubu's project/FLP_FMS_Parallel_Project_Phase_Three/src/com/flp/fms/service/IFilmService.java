package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;


import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService {
	public List<Language> getLanguages();

	public List<Category> getCategory();

	public void addFilm(Film film);

	public ArrayList<Film> getAllFilms();

	public boolean deleteFilm(int filmid );

	public List<Film> searchFilm(Film film);
	

	}
