package com.flp.fms.domain;

public class Language {

	//Private Fields
	private int language_Id;
	private String language_Name;
	private int film_id;

	

	//No Argument Constructor
	public Language() {
		super();
	}

	//Constructor with Fields
	public Language(int language_Id, String language_Name) {
		super();
		this.language_Id = language_Id;
		this.language_Name = language_Name;
	}

	@Override
	public String toString() {
		return "Language [language_Id=" + language_Id + ", language_Name=" + language_Name + ", film_id=" + film_id
				+ "]";
	}

	//Getter and Setter methods
	public int getLanguage_Id() {
		return language_Id;
	}

	public void setLanguage_Id(int language_Id) {
		this.language_Id = language_Id;
	}

	public String getLanguage_Name() {
		return language_Name;
	}

	public void setLanguage_Name(String language_Name) {
		this.language_Name = language_Name;
	}
	
	public int getFilm_id() {
		return film_id;
	}

	public void setFilm_id(int film_id) {
		this.film_id = film_id;
	}


}
