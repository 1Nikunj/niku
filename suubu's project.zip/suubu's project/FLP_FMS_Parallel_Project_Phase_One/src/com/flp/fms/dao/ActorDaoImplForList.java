package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;


public class ActorDaoImplForList implements IActorDao {
	


	@Override
	public List<Actor> getActors() {
List<Actor> actor=new ArrayList<>();
		
		actor.add(new Actor(101,"Tom","Jerry"));
		actor.add(new Actor(102,"Sharuk","Khan"));
		actor.add(new Actor(103,"Kamal","Hasan"));
		actor.add(new Actor(104,"Salman","Khan"));
		actor.add(new Actor(105,"Rajni","Kant"));
		actor.add(new Actor(106,"Hrithik","Roshan"));
		return actor;
		
	}

	

}
