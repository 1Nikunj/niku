package com.flp.fms.view;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		int option;
		String choice;
		UserInteraction user=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();

		do{													//User's choice arrested within do-while block for further operation inquiry
			menuSelection();
			System.out.println("Select your Option[1-6]");
			option=sc.nextInt();
		
			switch(option){
		
			case 1:
			Film film=user.addFilm(filmService.getLanguages(),filmService.getCategory(),actorService.getActors());
			//System.out.println(film);
			filmService.addFilm(film);
			break;
		
			case 2:
				int filmId = user.readFilmId();
				film = filmService.searchFilm(filmId);
				if(film==null)
					user.printFilm(film);
				else{
					
					user.printFilm(film);
					film = user.addFilm(filmService.getLanguages(), filmService.getCategory(),
							actorService.getActors());
					film.setFilm_Id(filmId);
					filmService.updateFilm(film);       
				}
		
				break;
			
			case 3:
				System.out.println("\t1.remove by id\n\t2.remove by title\n\t3.remove by rating\n"
						+ "\t4.remove film by actor\n");
				System.out.println("enter your option");
				int opt=sc.nextInt();
				switch (opt) {
				
					case 1:
						filmService.removeFilm(user.readFilmId());
						break;
						
					case 2:
						filmService.removeFilm(user.readTitle());
						break;
						
					case 3:
						filmService.removeFilmByRating(user.readRating());
						break;
						
					case 4:
						filmService.removeFilm(user.selectActor(actorService.getActors()));
						break;

				default:
					filmService.removeFilmByRating(user.readRating());
					break;
				}
				
				break;
			
			case 4:
				System.out.println("\t1.search by Id\n\t2.search by Title\n\t3.search by Rating\n"
						+ "\t4.search by Actor\n\t5.search by Language");
				System.out.println("Enter your option");
				int op=sc.nextInt();
				
				switch(op){
				
					case 1:
						film = filmService.searchFilm(user.readFilmId());
						user.printFilm(film);
						break;
						
					case 2:
						film = filmService.searchFilm(user.readTitle());
						user.printFilm(film);
						break;
						
					case 3:
						List<Film> films = filmService.searchFilmByRating(user.readRating());
						user.getAllFilm(films);;
						break;
						
					case 4:
						List<Film> selectedFilms = filmService.searchFilm(user.selectActor(actorService.getActors()));
						user.getAllFilm(selectedFilms);
						break;
						
					case 5:
						List<Language> allLanguages = filmService.getLanguages();
						List<Film> selectedFilms2 = filmService.searchFilm(user.selectLanguage(allLanguages));
						user.getAllFilm(selectedFilms2);
						break;
						
					default:
						System.out.println("Wrong Option Entered");
				}
				break;
			
			
			case 5:
			Map<Integer, Film>  film_lst= filmService.getAllFilms();
			Collection<Film> lst=film_lst.values();
			user.getAllFilm(lst);								//Calling getAllFilm method from UserInteraction class
			break;
			
			case 6:
			System.exit(0);
		
			}System.out.println("Wish to do more Operation?[y|n]");
			 choice=sc.next();
		
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	}
	
	

	public static void menuSelection() {
		
		
		System.out.println("1.Add Film");
		System.out.println("2.Update Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.Get All Films");
		System.out.println("6.Exit");
	}
	
	
}
