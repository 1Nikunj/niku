package org.capgemini.dao;

import org.capgemini.model.UploadFile;

public interface FileUploadDAO {
    void save(UploadFile uploadFile);
}