function validateForm()

{

 var flag=true;
	
	
	
	var title = CreateFilm1.filmtitle.value;
	
	var length = CreateFilm1.filmlength.value;
	
	var cost=CreateFilm1.replacementcost.value;
	
	var rentalDate = CreateFilm1.rentalduration.value;
	
	var releaseyear=CreateFilm1.releasedate.value;
	
	var letters = /^[A-Za-z0-9_ ]*$/;
	

	 
		
	if((title=="" || title==null) || !title.match(letters) )
	
	{
		
		document.getElementById("titleerr").innerHTML="* Please enter a title";
		
		flag=false;
	}
	
	else
	 {
		document.getElementById("titleerr").innerHTML="";
	 }
	
   if((length == ""||length == null) || length > 1000)
   
   {
		
		document.getElementById("lenghterr").innerHTML="*Please enter a value below 1000";
		
		flag = false;
	}
   
	else
	 {
		document.getElementById("lenghterr").innerHTML="";
	    
	 }
   
   
   if((cost==""||cost==null) || cost < 10000)
   {
		
		document.getElementById("replacementcosterr").innerHTML="*Enter Valid Replacement Cost";
		
		flag = false;
	}
		
	else
		
		{
		document.getElementById("replacementcosterr").innerHTML="";
		
		}
   
   if((rentalDate==""||rentalDate==null) || rentalDate<releaseyear )
   {
		
		document.getElementById("rentaldurationerr").innerHTML="*RentalDate shhould be Greater than ReleaseDate";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("rentaldurationerr").innerHTML="";
		}
   
   
   if((releaseyear==""||releaseyear==null))
   {
		
		document.getElementById("relasedatrr").innerHTML="*Invalid release date";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("relasedatrr").innerHTML="";
		}
   
   
   
   
   
     
   return flag;
 
}




 
   