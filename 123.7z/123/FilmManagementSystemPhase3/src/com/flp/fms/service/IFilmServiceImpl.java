package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;


import com.flp.fms.dao.IFilmDao;
import com.flp.fms.dao.IFilmDaoIml;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class IFilmServiceImpl  implements IFilmService{
	IFilmDao filmDao=new IFilmDaoIml();
	
	//To Get Original Language
	@Override
	public List<Language> getLanguage() {
		
		return filmDao.getOriginalLanguage() ;
	}

	//To Get Category
	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}

	//To Add Film
	@Override
	public void addFilm(Film film) {
		
		filmDao.addFilm(film);
		
	}

	//To List all Films
	@Override
	public ArrayList<Film> getAllFilms() {
		return filmDao.getAllFilms();
	}

	//To Delete Film
	public Boolean deleteFilm(int filmid) {
		
		return filmDao.deleteFilm(filmid);
	}

	//To Search  Film 
	public ArrayList<Film> searchFilm(Film film) {
		
		return filmDao.searchFilm(film);
	}

	//To Update Film
	public int updateFilm(int id,Film film) {
		return filmDao.updateFilm(id,film);
		
		
	}

	//To Search Film By Id
	public Film getSearchFilmByID(int id) {
		return filmDao.getSearchFilmByID(id);
	}

}
