
package com.flp.fms.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImpl;




public class AddFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 IFilmService filmService=new IFilmServiceImpl();
			
			Film film = new Film();
			
			film.setTitle(request.getParameter("filmtitle"));       
		
			film.setDescription(request.getParameter("desc"));  
			
			String regdate=request.getParameter("releasedate");
			Date regDate=new Date(regdate);
			film.setReleaseYear(regDate);
			
			String duration1=request.getParameter("rentalduration");
			Date duration=new Date(duration1);
			film.setRetalDuration(duration);
			
			
			int length=Integer.parseInt(request.getParameter("filmlength"));
			film.setLength(length);
			
		    Language lang = new Language();
		    lang.setLanguage_Id(Integer.parseInt(request.getParameter("orgLang")));
		    film.setOriginalLanguage(lang);
			
			int cost=Integer.parseInt(request.getParameter("replacementcost"));
			film.setReplacementCost(cost);
			
            int ratings = Integer.parseInt(( request.getParameter("rating")));
			film.setRatings(ratings);
			
			film.setSpecialFeature((request.getParameter("features")));  
			
			Category cat = new Category();
			cat.setCategory_Id(Integer.parseInt(request.getParameter("category")));
			film.setCategory(cat);
			
			
			
			String [] str=request.getParameterValues("othrlang");
			List<Language> lang1=new ArrayList<>();
			for(String str1:str)
			{
		    Language language=new Language();
		    language.setLanguage_Id(Integer.parseInt(str1));
		    lang1.add(language);
			}
		film.setLanguages(lang1);
			String [] str2=request.getParameterValues("actor");
			List<Actor> act1=new ArrayList<>();
			for(String str3:str2){
				Actor act=new Actor();
				act.setActor_Id(Integer.parseInt(str3));
				act1.add(act);
			}
			film.setActors(act1);
			
			
			
			
			System.out.println(film);
	       
			//Persist customer Object into DataBase
			filmService.addFilm(film);
		
			
			request.getRequestDispatcher("pages/home.html");
	}

}
