package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImpl;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class DeletePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();

		
		IFilmServiceImpl filmservice=new IFilmServiceImpl();
		List<Film> film=(List<Film>) filmservice.getAllFilms();
	
		out.println("<head>");
		out.println( "<link type='text/css' rel='stylesheet' href='css/mystyle.css'>");
		out.println("</head>");
		out.println("<body id='add'>"
				+ "<h2 align='center'>List Of Films</h2>"
				+ "<table border=2px>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Original Language</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Category</th>"
				+ "<th>Languages</th>"
				+ "<th>Actors</th>"
				+ "</tr>");
		for(Film film1:film){
			List<Language> languages=film1.getLanguages();
			
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguage_Name()+",";
			}
			System.out.println(film1.getLanguages());
			List<Actor> actors=film1.getActors();
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getActor_FirstName()+" "+actor.getActor_LastName()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_Id()+"</td>");
			out.println("<td>"+film1.getTitle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getReleaseYear()+"</td>");
			out.println("<td>"+film1.getRetalDuration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguage_Name()+"</td>");
			out.println("<td>"+film1.getReplacementCost()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecialFeature()+"</td>");
			out.println("<td>"+film1.getCategory().getCategory_Name()+"</td>");
			out.println("<td>"+langs+"</td>");
			
			out.println("<td>"+actors1+"</td>");
			
			out.println("<td><a href='DeleteServlet?filmid="+film1.getFilm_Id()+"'><h5 style='color:#E45E9D;'>Delete </a></td>");
		}
			out.println("</table></body>");

	
	
	}
}
