package com.flp.fms.Test;

import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImplementation;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImpl;

public class UnitTestClass {

	@Test
	public void test() {

	}

	IFilmService  serviceFilm=new IFilmServiceImpl();
	IActorService actorservice=new IActorServiceImplementation();
	
	/*
	@Test
	public void WhenListOfActorsIsNotNull(){
		List<Actor> actors=new ArrayList<>();
		actors.add(new Actor(1,"Akashay","Kumar"));
		actors.add(new Actor(2,"Shahid","Kapur"));
		actors.add(new Actor(3,"Shaharukh","Khan"));
		actors.add(new Actor(4,"Kareena","Kapoor"));
		actors.add(new Actor(5,"Aishwarya","Ray"));
		actors.add(new Actor(6,"Deepika","Padukon"));
		actors.add(new Actor(7,"Varun","Dhawan"));
		actors.add(new Actor(8,"Shraddha","Kapoor"));
		actors.add(new Actor(9,"Kruti","senon"));
		actors.add(new Actor(10,"vidya","Balan Roy Kapoor"));
		actors.add(new Actor(11,"Abhishek","Bacchan"));
		actors.add(new Actor(12,"Amitab","Bacchan"));
		
		assertEquals(actorservice.getActorList(), actors);
		
}*/
	
	@Test
	public void WhenListOfLanguagesIsNotNull(){
		List<Language> langs=new ArrayList<>();
		langs.add(new Language(1,"English"));
		langs.add(new Language(2,"Hindi"));
		langs.add(new Language(3,"Telegu"));
		langs.add(new Language(4,"Marathi"));
		langs.add(new Language(5,"Kananta"));
		langs.add(new Language(6,"Tamil"));
		langs.add(new Language(7,"Malayalam"));
		assertEquals(langs,serviceFilm.getLanguage());
	}
	
	/*@Test
	public void WhenListOfLanguagesIsNull(){
		assertEquals(null,null);
	}
	*/
	/*@Test
	public void WhenAddFilmObjectIsNotNull() throws ParseException{
		Film film=new Film();
		film.setFilm_Id(1);
		film.setCategory(new Category(1,"Romance"));
		film.setLength(456);
		List<Actor> actors=new ArrayList>();
		actors.add(new Actor(1,"Akashay","Kumar"));
		actors.add(new Actor(4,"Kareena","Kapoor"));
		film.setActors(actors);
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1,"English"));
		languages.add(new Language(2,"Hindi"));
		film.setLanguages(languages);
		Language orglang=new Language();
		orglang.setLanguage_Id(1);
		orglang.setLanguage_Name("English");
		film.setOriginalLanguage(orglang);
		film.setTitle("Adalat");
		film.setDescription("suspense");
		String strDate1 = "2011-01-06";
		DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter1.parse(strDate1);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		film.setReleaseYear(sqlDate);
		String strDate2 = "2012-01-06";
		DateFormat formatter2 = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date2 = formatter2.parse(strDate2);
		java.sql.Date sqlDate2 = new java.sql.Date(date.getTime());
		film.setRetalDuration(sqlDate2);
		assertEquals(serviceFilm.addFilm(film),true);
	}

	*/	

	    


}
