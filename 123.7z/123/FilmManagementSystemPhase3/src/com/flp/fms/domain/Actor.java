package com.flp.fms.domain;

public class Actor {
	//Actor Parameters
	private int actor_Id;
	private String actor_FirstName;
	private String actor_LastName;
	
	
	//No Arg Constructor
	public Actor(){}

	//Parameterized Constructor
	public Actor(int actor_Id, String actor_FirstName, String actor_LastName) {
		super();
		this.actor_Id = actor_Id;
		this.actor_FirstName = actor_FirstName;
		this.actor_LastName = actor_LastName;
	}

	//Setters and Getters
	public int getActor_Id() {
		return actor_Id;
	}

	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}

	public String getActor_FirstName() {
		return actor_FirstName;
	}

	public void setActor_FirstName(String actor_FirstName) {
		this.actor_FirstName = actor_FirstName;
	}

	public String getActor_LastName() {
		return actor_LastName;
	}

	public void setActor_LastName(String actor_LastName) {
		this.actor_LastName = actor_LastName;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actor_FirstName == null) ? 0 : actor_FirstName.hashCode());
		result = prime * result + actor_Id;
		result = prime * result + ((actor_LastName == null) ? 0 : actor_LastName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actor other = (Actor) obj;
		if (actor_FirstName == null) {
			if (other.actor_FirstName != null)
				return false;
		} else if (!actor_FirstName.equals(other.actor_FirstName))
			return false;
		if (actor_Id != other.actor_Id)
			return false;
		if (actor_LastName == null) {
			if (other.actor_LastName != null)
				return false;
		} else if (!actor_LastName.equals(other.actor_LastName))
			return false;
		return true;
	}

	//To String Method
	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", actor_FirstName=" + actor_FirstName + ", actor_LastName="
				+ actor_LastName + ", film_Id=" + "]";
	}
	
	
	
	
	
}
