function validateField(){
	var flag=true;
	var uname=form1.uname.value;
	
	var upwd=form1.upwd.value;
	
		if(uname==""||uname==null)
		{
		document.getElementById("unameErr").innerHTML="*Please enter UserName";
		flag=false;
		}else
			document.getElementById("unameErr").innerHTML="";
	
		if(upwd==""||upwd==null)
		{
		document.getElementById("upwdErr").innerHTML="*Please enter Password";
		flag=false;
		}else
			document.getElementById("upwdErr").innerHTML="";
	
	
	return flag;
}

function displayCustomer(){
	//alert("hello");
	var customerId=f1.custId.value;	
		//alert(employeeId);
		//Ajax Code 
		var xhr = new XMLHttpRequest();
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4) {
	            var data = xhr.responseText;
	             document.getElementById('displayCust').innerHTML=data;
	        }
	    }
	    xhr.open('GET', 'DisplayCustomerServlet?custId='+customerId, true);
	  
	    xhr.send(null);
		
	   
	}

