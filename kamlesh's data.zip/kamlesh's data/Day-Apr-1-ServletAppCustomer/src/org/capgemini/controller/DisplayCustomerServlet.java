package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;


public class DisplayCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginService loginService=new LoginServiceImpl();
		String custId=request.getParameter("custId");
		
			Customer cust=loginService.searchCustomer(Integer.parseInt(custId));
		
		PrintWriter out=response.getWriter();
		out.println("<h1 align='center'>Customer Details</h1>");
		out.println("<b>Employee Id: </b>" + cust.getCustId() +"<br><br>" );
		out.println("<b>Employee FirstName: </b>" + cust.getFirstName() +"<br><br>" );
		out.println("<b>Employee LastName: </b>" + cust.getLastName() +"<br><br>" );
	
	
	
	}

}
