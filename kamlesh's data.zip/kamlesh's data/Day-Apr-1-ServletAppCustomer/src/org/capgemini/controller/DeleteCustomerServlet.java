package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class DeleteCustomerServlet
 */
public class DeleteCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		LoginService loginService=new LoginServiceImpl();
		ArrayList<Customer> customers=loginService.getAllCustomers();
		
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>List All Cutomers</head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Customer Id</th>"
				+ "<th>FirstName</th>"
				+ "<th>LastName</th>"
				+ "<th>Address</th>"
				+ "<th>Gender</th>"
				+ "<th>Registration Date</th>"
				+ "<th>Registration Fees</th>"
				+ "<th>Customer Type</th>"
				+ "<th>Delete</th>"
				+ "</tr>");
		
		for(Customer cust:customers){
			
			out.println("<tr>");
			out.println("<td>"+cust.getCustId()+"</td>");
			out.println("<td>"+cust.getFirstName()+"</td>");
			out.println("<td>"+cust.getLastName()+"</td>");
			out.println("<td>"+cust.getAddress()+"</td>");
			out.println("<td>"+cust.getGendar()+"</td>");
			out.println("<td>"+cust.getRegDate()+"</td>");
			out.println("<td>"+cust.getRegFees()+"</td>");
			out.println("<td>"+cust.getCustType()+"</td>");
			out.println("<td><a href='DeleteServlet?custId="+cust.getCustId()+"'>Delete</a></td>");
		}
		
		out.println("</table></body>");
		out.println("</html>");
		
		
	}

}




	
	
