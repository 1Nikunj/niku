package org.capgemini.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;



/**
 * Servlet implementation class SaveCustomerServlet
 */
public class SaveCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		LoginService loginService=new LoginServiceImpl();
		
		Customer customer=new Customer();
		
		customer.setFirstName(request.getParameter("fname"));
		customer.setLastName(request.getParameter("lname"));
		customer.setAddress(request.getParameter("address"));
		customer.setGendar(request.getParameter("gendar"));
		
		String date=request.getParameter("regdate");
		Date regDate=new Date(date);
		customer.setRegDate(regDate);
		
		double regFees=Double.parseDouble(request.getParameter("regfees"));
		customer.setRegFees(regFees);
		
		
		
		String custType=request.getParameter("custType");
		customer.setCustType(custType);
		
		System.out.println(customer);
		
		//Persist employee Object into DataBase
		loginService.saveCustomer(customer);
		
		//response.sendRedirect("SaveEmployeeServlet");
		request.getRequestDispatcher("pages/Customer.html").forward(request, response);
		
	}

}




