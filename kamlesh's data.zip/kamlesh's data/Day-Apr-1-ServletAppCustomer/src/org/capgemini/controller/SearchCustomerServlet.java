package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class SearchCustomerServlet
 */
public class SearchCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginService loginService=new LoginServiceImpl();
		//int custId=Integer.parseInt(request.getParameter("custid"));
		ArrayList<Customer> customers=loginService.getAllCustomers();
		//Customer customer=new Customer();
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head><title>Search Employee</title>"
				+ "<script type='text/javascript' src='script/validate.js'></script>"
				+ "<link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
							
				+ "</head>"
				+ "<body><form name='f1'>"
				+ "<div>"
				+ "<label>Choose Customer Id</label>"
				+ "<select name='CustId'>");
		for(Customer cust:customers){
			out.println("<option value='"+ cust.getCustId()+"'>" + cust.getCustId() +"</option>");
		}
				out.println("</select>"
						+ "<input type='button' name='Search' value='Search' onClick='displayCustomers()'>"
				+ "</div>"
				+ "<div id='displayCust'> "
				+ "<h2>Customer Details</h2>"
				
				+ "</div>"
				+ "</form></body>");
		
		
		out.println("</html>");
	
	}

}
