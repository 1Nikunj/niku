package org.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public class LoginDaoImpl implements LoginDao {

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from LoginDetail where userName=? and userPwd=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			
			pst.setString(1, loginUser.getUserName());
			pst.setString(2, loginUser.getUserPwd());
		
	
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	
	public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/custdb","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}


	
	@Override
	public void saveCustomer(Customer customer) {
		
		Connection con=getConnection();
		
		String sql="insert into customer(firstName,lastName,address,gendar,regDate,regFees,custType)"
											+ "	 values(?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, customer.getFirstName());
			pst.setString(2, customer.getLastName());
			pst.setString(3, customer.getAddress());
			pst.setString(4, customer.getGendar());
			pst.setDate(5,new Date(customer.getRegDate().getTime()));
			pst.setDouble(6, customer.getRegFees());
			pst.setString(7, customer.getCustType());
			
			
			int count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}


	@Override
	public ArrayList<Customer> getAllCutomers() {
		ArrayList<Customer> customers=new ArrayList<>();
		
		
		String sql="select * from Customer";
		Connection con=getConnection();
		try{
			
			PreparedStatement pst=con.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			
			while (rs.next()){
				
				Customer cust=new Customer();
				
				cust.setCustId(rs.getInt(1));
				cust.setFirstName(rs.getString(2));
				cust.setLastName(rs.getString(3));
				cust.setAddress(rs.getString(4));
				cust.setGendar(rs.getString(5));
				
				//dd-mmm-yyyy--> sql to util date conversion
				cust.setRegDate(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				cust.setRegFees(rs.getDouble(7));
				cust.setCustType(rs.getString(8));
				
				// adding all customers
				customers.add(cust);
			}	
			}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		return customers;
	}


	@Override
	public boolean deleteCustomer(int custId) {
		Connection con=getConnection();
		boolean flag=false;
		String sql="delete from customer where custId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, custId);
	
			int count=pst.executeUpdate();
			
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}


	@Override
	public Customer searchCustomer(int custId) {

		Connection con=getConnection();
		
		Customer cust=new Customer();
		
		String sql="select * from employee where empId=?";
		try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, custId);
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()){
				cust.setCustId(rs.getInt(1));
				cust.setFirstName(rs.getString(2));
				cust.setLastName(rs.getString(3));
				cust.setAddress(rs.getString(4));
				cust.setGendar(rs.getString(5));
				
				//dd-mmm-yyyy--> sql to util date conversion
				cust.setRegDate(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				cust.setRegFees(rs.getDouble(7));
				cust.setCustType(rs.getString(8));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return cust;
	}
	
	
}
