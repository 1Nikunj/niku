package org.capgemini.dao;

import java.util.ArrayList;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public interface LoginDao {

	
	public boolean isValidLogin(LoginUser loginUser) ;
	
	public void saveCustomer(Customer customer);
	
	public ArrayList<Customer> getAllCutomers();
	
	public boolean deleteCustomer(int custId);
	
	public Customer searchCustomer(int custId);	

}
