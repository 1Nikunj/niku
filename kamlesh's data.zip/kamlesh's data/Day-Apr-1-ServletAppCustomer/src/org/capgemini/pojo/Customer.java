package org.capgemini.pojo;

import java.util.Date;

public class Customer {

	private int custId;
	private String firstName;
	private String lastName;
	private String address;
	private String gendar;
	private Date regDate;
	private double regFees;
	private String custType;
	
	
	
	public Customer(){}



	public Customer(int custId, String firstName, String lastName, String address, String gendar, Date regDate,
			double regFees, String custType) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gendar = gendar;
		this.regDate = regDate;
		this.regFees = regFees;
		this.custType = custType;
	}



	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getGendar() {
		return gendar;
	}



	public void setGendar(String gendar) {
		this.gendar = gendar;
	}



	public Date getRegDate() {
		return regDate;
	}



	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}



	public double getRegFees() {
		return regFees;
	}



	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}



	public String getCustType() {
		return custType;
	}



	public void setCustType(String custType) {
		this.custType = custType;
	}



	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", gendar=" + gendar + ", regDate=" + regDate + ", regFees=" + regFees + ", custType="
				+ custType + "]";
	}
	
	
	
	
}
