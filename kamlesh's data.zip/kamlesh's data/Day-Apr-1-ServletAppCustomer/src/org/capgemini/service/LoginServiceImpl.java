package org.capgemini.service;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

import java.util.ArrayList;

import org.capgemini.dao.LoginDao;
import org.capgemini.dao.LoginDaoImpl;



public class LoginServiceImpl implements LoginService {

	private LoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
		return loginDao.isValidLogin(loginUser);
	}

	@Override
	public void saveCustomer(Customer customer) {
		loginDao.saveCustomer(customer);
	}

	@Override
	public ArrayList<Customer> getAllCustomers() {
		
		return loginDao.getAllCutomers();
	}

	@Override
	public boolean deleteCustomer(int custId) {
		// TODO Auto-generated method stub
		return loginDao.deleteCustomer(custId);
	}

	@Override
	public Customer searchCustomer(int custId) {
		// TODO Auto-generated method stub
		return loginDao.searchCustomer(custId);
	}

}


