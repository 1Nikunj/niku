package org.capgemini.service;

import java.util.ArrayList;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public interface LoginService {

	public boolean isValidLogin(LoginUser loginUser);
	public void saveCustomer(Customer customer);

	public ArrayList<Customer> getAllCustomers();
	
	public boolean deleteCustomer(int custId);
	
	public Customer searchCustomer(int custId);
	
}