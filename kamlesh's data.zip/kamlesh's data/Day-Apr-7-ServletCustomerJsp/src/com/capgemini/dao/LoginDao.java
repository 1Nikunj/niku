package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.pojo.Customer;
import com.capgemini.pojo.LoginUser;

public interface LoginDao {
	
	public boolean isValidLogin(LoginUser loginUser) ;
	public void saveCustomer(Customer customer);
	/*public ArrayList<Customer> getAllCustomers();*/
	public ArrayList<Customer> getAllCustomer();
	public boolean deleteCustomer(int cusId);
	public Customer searchCustomer(int customerId);
	public ArrayList<Customer> viewAllCustomer(int offset,int noOfRecords);
}


