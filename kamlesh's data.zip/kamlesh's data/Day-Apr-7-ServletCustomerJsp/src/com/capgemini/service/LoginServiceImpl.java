package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.dao.LoginDao;
import com.capgemini.dao.LoginDaoImpl;
import com.capgemini.pojo.Customer;
import com.capgemini.pojo.LoginUser;

public class LoginServiceImpl implements LoginService {
	
	
	private LoginDao loginDao=new LoginDaoImpl();

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
		/*boolean flag=false;
		
		if(loginUser.getUserName().equals("tom") && 
				loginUser.getUserPwd().equals("12345"))
			flag=true;
		*/
		return loginDao.isValidLogin(loginUser);
	}

	@Override
	public void saveCustomer(Customer customer) {
		loginDao.saveCustomer(customer);
	}

	/*@Override
	public ArrayList<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}*/

	@Override
	public ArrayList<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return loginDao.getAllCustomer();
	}
	public boolean deleteCustomer(int cusId) {
		// TODO Auto-generated method stub
		return loginDao.deleteCustomer(cusId);
	}

	public Customer searchCustomer(int customerId) {
		// TODO Auto-generated method stub
		return loginDao.searchCustomer(customerId);
	}
	public ArrayList<Customer> viewAllCustomer(int offset,int noOfRecords){
		return loginDao.viewAllCustomer(offset,noOfRecords);
	}

}


