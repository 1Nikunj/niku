package com.capgemini.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dao.LoginDaoImpl;
import com.capgemini.pojo.Customer;

@WebServlet("/ListAllServletJsp")
public class ListAllServletJsp extends HttpServlet {
	private static final long serialVersionUID = 1L;


		public ListAllServletJsp(){
			super();
		}
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			LoginDaoImpl login=new LoginDaoImpl();
			int page = 1;
	        int recordsPerPage = 5;
	        if(request.getParameter("page") != null)
	            page = Integer.parseInt(request.getParameter("page"));
	        ArrayList<Customer> list = login.viewAllCustomer((page-1)*recordsPerPage,
	                                 recordsPerPage);
	        int noOfRecords = login.getNoOfRecords();
	        int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
	        request.setAttribute("customerList", list);
	        request.setAttribute("noOfPages", noOfPages);
	        request.setAttribute("currentPage", page);
	        RequestDispatcher view = request.getRequestDispatcher("pages/diplayCustomer.jsp");
	        view.forward(request, response);	
		}

	}
