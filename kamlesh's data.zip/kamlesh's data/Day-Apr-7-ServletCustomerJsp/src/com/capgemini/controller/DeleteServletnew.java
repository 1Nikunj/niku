package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.pojo.Customer;
import com.capgemini.service.LoginService;
import com.capgemini.service.LoginServiceImpl;


@WebServlet("/DeleteServletnew")
public class DeleteServletnew extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginService loginService=new LoginServiceImpl();
		
		ArrayList<Customer> customer=loginService.getAllCustomer(); 


		PrintWriter out=response.getWriter();
	
		out.println("<html>");
		out.println("<head>List All Customer</head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Customer Id</th>"
				+ "<th>FirstName</th>"
				+ "<th>LastName</th>"
				+ "<th>Address</th>"
				+ "<th>Gender</th>"
				+ "<th>Date Of Registration</th>"
				+ "<th>Registartion Fees</th>"
				+ "<th>Customer Type</th>"
				+ "<th>Delete</th>"
				+ "</tr>");

		for(Customer cust:customer){
			out.println("<tr>");
			out.println("<td>"+cust.getCusId()+"</td>");
			out.println("<td>"+cust.getFirstName()+"</td>");
			out.println("<td>"+cust.getLastName()+"</td>");
			out.println("<td>"+cust.getAddress()+"</td>");
			out.println("<td>"+cust.getRegDate()+"</td>");
			out.println("<td>"+cust.getRegFees()+"</td>");
			out.println("<td>"+cust.getCusType()+"</td>");
			out.println("<td><a href='DeleteServletNew1?cusId="+cust.getCusId()+"'>Delete</a></td>");
			
			out.println("</tr>");
		}
			out.println("</table></body>");

			out.println("</html>");


		}

}
