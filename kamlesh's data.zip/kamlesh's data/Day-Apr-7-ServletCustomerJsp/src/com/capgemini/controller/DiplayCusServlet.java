package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.pojo.Customer;
import com.capgemini.service.LoginService;
import com.capgemini.service.LoginServiceImpl;

@WebServlet("/DiplayCusServlet")
public class DiplayCusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginService loginService=new LoginServiceImpl();
		String cusId=request.getParameter("cusId");
		
		Customer cus=loginService.searchCustomer(Integer.parseInt(cusId));
		
		PrintWriter out=response.getWriter();
		out.println("<h1 align='center'>Customer Details</h1>");
		out.println("<b>Customer Id: </b>" + cus.getCusId() +"<br><br>" );
		out.println("<b>Customer FirstName: </b>" + cus.getFirstName() +"<br><br>" );
		out.println("<b>Customer LastName: </b>" + cus.getLastName() +"<br><br>" );	
	}


}