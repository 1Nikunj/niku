package org.capgemin.SetPrac;

import java.util.HashSet;
import java.util.Iterator;

public class TestHashMain {

	
			public static void main(String[] args) {
		
			//Creating Employee object
				HashSet<Employee> set=new HashSet<>();
			
				set.add(new Employee(101, "Tom","Jerry" ));
				set.add(new Employee(102, "Raj", "Pal" ));
				set.add(new Employee(103, "Om","Sharma" ));
				set.add(new Employee(104, "Jai","Sharma" ));
				set.add(new Employee(105, "Viru","Dhawan" ));
				set.add(new Employee(106, "Sonu","Warma" ));
				set.add(new Employee(107, "Monu","Singh" ));
				set.add(new Employee(108, "Ravi","Kumar" ));
				set.add(new Employee(109, "Nick","Samuel" ));
				set.add(new Employee(110, "Tom","Cruise" ));
				
			//Using Iterator 
				Iterator<Employee> itr=set.iterator();
				
				int i=1;
				while(itr.hasNext()){
					System.out.println(i);
					System.out.println(itr.next());
					i++;
				}
			}

}
