package org.capgemin.MapAssignment;

public class BootClass {

	public static void main(String[] args) {
	
		
		
	}

}
