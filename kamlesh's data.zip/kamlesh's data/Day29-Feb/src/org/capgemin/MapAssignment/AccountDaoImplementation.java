package org.capgemin.MapAssignment;

import java.util.HashMap;

public class AccountDaoImplementation implements AccountDAO{

		HashMap<Integer,String> maps=new HashMap<>();
	
	
	@Override
	public void createAccount() {
		
		
	}

	@Override
	public void deleteAccount() {
		
		
	}

	@Override
	public void listAllAccount() {
		
		
	}

	@Override
	public void searchAccount() {
		
		
	}

	@Override
	public void updateAccount() {
		
		
	}

	@Override
	public void sortAccount() {
		
	}

	
	
}
