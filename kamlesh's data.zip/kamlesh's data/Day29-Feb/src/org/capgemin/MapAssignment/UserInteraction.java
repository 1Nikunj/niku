package org.capgemin.MapAssignment;

import java.util.Date;
import java.util.Scanner;


public class UserInteraction {

	public Account getCustomerDetails()
	{
			 Account acc=new Account();
			  int account_id;
			  String account_name;
			  String open_date;
			  String account_type;
			  double open_balance;
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Account id:");
			account_id=sc.nextInt();
			
			System.out.println("Enter Account name:");
			account_name=sc.next();
			
			System.out.println("Enter opened date:");
			open_date=sc.next();
			
			System.out.println("Enter account type:");
			account_type=sc.next();
			
			System.out.println("Enter Open Balance:");
			open_balance=sc.nextDouble();
			
			
			acc.setAccount_id(account_id);
			acc.setAccount_name(account_name);
			
			Date d=new Date(open_date);
			acc.setOpen_date(d);
			
			acc.setAccount_type(account_type);
			acc.setOpen_balance(open_balance);
			
			
			return acc;
		
	}
	
}
