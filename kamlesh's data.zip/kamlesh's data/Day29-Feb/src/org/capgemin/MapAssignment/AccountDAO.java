package org.capgemin.MapAssignment;

public interface AccountDAO {

	public void createAccount();
	public void deleteAccount();
	public void listAllAccount();
	public void searchAccount();
	public void updateAccount();
	public void sortAccount();
	
	
	
}
