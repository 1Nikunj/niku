package org.capgemin.MapAssignment;
import java.util.Date;

public class Account {

	private int account_id;
	private String account_name;
	private Date open_date;
	private String account_type;
	private double open_balance;
	
	public Account(){}

	public Account(int account_id, String account_name, Date open_date, String account_type, double open_balance) {
		super();
		this.account_id = account_id;
		this.account_name = account_name;
		this.open_date = open_date;
		this.account_type = account_type;
		this.open_balance = open_balance;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

	public String getAccount_name() {
		return account_name;
	}

	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}

	public Date getOpen_date() {
		return open_date;
	}

	public void setOpen_date(Date open_date) {
		this.open_date = open_date;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String accont_type) {
		this.account_type = accont_type;
	}

	public double getOpen_balance() {
		return open_balance;
	}

	public void setOpen_balance(double open_balance) {
		this.open_balance = open_balance;
	}

	@Override
	public String toString() {
		return "Account [account_id=" + account_id + ", account_name=" + account_name + ", open_date=" + open_date
				+ ", accont_type=" + account_type + ", open_balance=" + open_balance + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((account_type == null) ? 0 : account_type.hashCode());
		result = prime * result + account_id;
		result = prime * result + ((account_name == null) ? 0 : account_name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(open_balance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((open_date == null) ? 0 : open_date.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (account_type == null) {
			if (other.account_type != null)
				return false;
		} else if (!account_type.equals(other.account_type))
			return false;
		if (account_id != other.account_id)
			return false;
		if (account_name == null) {
			if (other.account_name != null)
				return false;
		} else if (!account_name.equals(other.account_name))
			return false;
		if (Double.doubleToLongBits(open_balance) != Double.doubleToLongBits(other.open_balance))
			return false;
		if (open_date == null) {
			if (other.open_date != null)
				return false;
		} else if (!open_date.equals(other.open_date))
			return false;
		return true;
	}
	
	
	
	
}
