package org.capgemin.SetAssignment;


import java.util.ArrayList;
import java.util.Collections;
//import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.TreeSet;

public class BootClass {
	
static String a;
public static void main(String args[])
{
	
	int choice;
	
	Scanner sc=new Scanner(System.in);
	//HashSet<Employee> set= new HashSet<>();
	//LinkedHashSet<Employee> set= new LinkedHashSet<>();
	//TreeSet<Employee> set=new TreeSet<>();
	ArrayList<Employee> set=new ArrayList<>();
	set.add(new Employee(1,"Tom","Jerry",12000));
	set.add(new Employee(2,"Jai","sss",13000));
	set.add(new Employee(3,"Om","xyz",14000));
	set.add(new Employee(4,"Sonu","abc",15000));
	set.add(new Employee(5,"Niki","ijkl",16000));
	set.add(new Employee(6,"Monu","lmn",15500));
	set.add(new Employee(7,"Rocky","opqr",16500));
	set.add(new Employee(8,"Ravi","stuv",17000));
	set.add(new Employee(9,"Peter","hkdf",13500));
	set.add(new Employee(10,"Raj","wxd",12500));
	set.add(new Employee(1,"Tom","Jerry",12000));
	//set.add(null);
	//Collections.sort(set);
	//Iterator<Employee> itr= set.iterator();
	//while(itr.hasNext()){
		//System.out.println(itr.next());
	//}
	do{
	System.out.println("Enter your choice:\n1.Sort By Id.\n2.Sort by Firstname.\n3.Sort by Last name.\n4.Sort by salary.");
choice=sc.nextInt();
switch(choice){
case 1:{
	Collections.sort(set);
	Iterator<Employee> itr= set.iterator();
	while(itr.hasNext()){
		System.out.println(itr.next());
	}
	break;
}
case 2:{
	Collections.sort(set, new sortByFirstname());
	Iterator<Employee> itr= set.iterator();
	while(itr.hasNext()){
		System.out.println(itr.next());
}
	break;
}
case 3:{
	Collections.sort(set, new sortByLastname());
	Iterator<Employee> itr= set.iterator();
	while(itr.hasNext()){
		System.out.println(itr.next());
}
	break;
}
case 4:{
	Collections.sort(set, new SortBySalary());
	Iterator<Employee> itr= set.iterator();
	while(itr.hasNext()){
		System.out.println(itr.next());
}
	break;
}
}
System.out.println("Do you wish to continue:If Yes the press 'Y','y'");
a=sc.next();
}while(a.charAt(0)=='y'||a.charAt(0)=='Y');
}
}

