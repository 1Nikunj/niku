package org.capgemini.pojo;

import java.util.Date;

public class Employee {

	
	private int empId;
	private String firstName;
	private String lastName;
	private String address;
	private String gendar;
	private String hobbies;
	private String department;
	private Date empDob;
	private double salary;
	
	
	public Employee(){}
	
	public Employee(int empId, String firstName, String lastName, String address, String gendar, String hobbies,
			String department, Date empDob, double salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gendar = gendar;
		this.hobbies = hobbies;
		this.department = department;
		this.empDob = empDob;
		this.salary = salary;
	}
	
	public int getEmpId() {
		return empId;
	}
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the gendar
	 */
	public String getGendar() {
		return gendar;
	}
	/**
	 * @param gendar the gendar to set
	 */
	public void setGendar(String gendar) {
		this.gendar = gendar;
	}
	/**
	 * @return the hobbies
	 */
	public String getHobbies() {
		return hobbies;
	}
	/**
	 * @param hobbies the hobbies to set
	 */
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}
	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}
	/**
	 * @return the empDob
	 */
	public Date getEmpDob() {
		return empDob;
	}
	/**
	 * @param empDob the empDob to set
	 */
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", gendar=" + gendar + ", hobbies=" + hobbies + ", department=" + department + ", empDob="
				+ empDob + ", salary=" + salary + "]";
	}
	
	
	
	
}
