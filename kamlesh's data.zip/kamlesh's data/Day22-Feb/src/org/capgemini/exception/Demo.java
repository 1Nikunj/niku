package org.capgemini.exception;


public class Demo {

	public static void main(String[] args){
		
		try{
		
			if(args.length==2){
		
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		
			int ans;
			
			ans=num1/num2;
			
			System.out.println("Answer :" + ans);
				
		
		}
		}
		catch(ArithmeticException|NumberFormatException|ArrayIndexOutOfBoundsException ex){
			ex.printStackTrace();
			
			//System.out.println(ex.getMessage());
		}
		catch (Exception e) {
			
			System.out.println(e.getMessage());
		}
		finally{
			
			System.out.println("Finally Executed");
		}
	
		System.out.println("Program Completed");
		
	
}

	}
	
	
	
	

