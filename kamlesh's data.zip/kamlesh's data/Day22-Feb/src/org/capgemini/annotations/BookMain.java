package org.capgemini.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;


public class BookMain {

@Publisher(publisherName="Jai",publishedDate="22-feb-2016")

	
	public static void main(String[] args) {
		
		 Book book=new Book(1001,"Java Book");
		 
		 
		
	}

}
