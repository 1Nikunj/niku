package org.capgemini.Collection;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class TestArrayList {

	public static void main(String[] args) {
	
		
		
		List<String> mylist=new ArrayList<>();
		
		mylist.add("Om");
		mylist.add("jai");
		mylist.add("jaggu");
		mylist.add("null");
		//mylist.add(null);
		mylist.add("tom");
		mylist.add("jerry");
		mylist.add("Om");
		mylist.add("jai");

	
			
		
	/*	for(String str:mylist){
			
			System.out.println(str);
			
		}
	*/
		
		
	/*	Iterator<String> itr=mylist.iterator();
		
		while(itr.hasNext()){
			
			System.out.println(itr.next());
			
		}
		*/
			
		
		ListIterator<String> litr=mylist.listIterator();
		
		while(litr.hasNext()){
			String str=litr.next();
			if(str.equals("jaggu"))
				litr.remove();
			System.out.print(str+ "->");
		}
		

		System.out.println();
		
		System.out.println(mylist);
		
		
		while(litr.hasPrevious()){
			
			System.out.print(litr.previous() + "--->");
		}
		
		System.out.println();
		
		mylist.add("sonu");
	
		System.out.println(mylist);
	

	
	
	
	
	
}
}
