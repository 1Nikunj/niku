package org.capgemini.Collection;
import java.util.LinkedList;


public class LinkedListPrac {

	public static void main(String[] args) {
		
		LinkedList<Integer> list=new LinkedList<>();
		
		list.add(20);
		list.add(30);
		list.add(null);
		list.add(new Integer(-15));
		list.add(25);
		list.add(20);
		list.add(30);
		
		
		System.out.println(list);
		
		System.out.println(list.remove(new Integer(25)));
		
		list.add(5, 50);
		System.out.println(list);
		
		list.addLast(70);
		System.out.println(list);
		
		System.out.println(list.getFirst());
	
		System.out.println(list.getLast());
		
		list.offer(18);
		System.out.println(list);
		
		list.offerFirst(18);
		System.out.println(list);
		
		
		list.offerLast(46);
		System.out.println(list);
		
		System.out.println(list.peek());
		
		System.out.println(list.peekFirst());
		
		System.out.println(list.peekLast());
		
		System.out.println(list.poll());
		System.out.println(list);
		
		System.out.println(list.pollLast());
		System.out.println(list);
		
		
		System.out.println(list.pop());
		System.out.println(list);
		
		list.push(80);
		System.out.println(list);
		
		list.removeFirst();
		System.out.println(list);
	
		list.removeLast();
		System.out.println(list);
		
		list.removeFirstOccurrence(30);
		System.out.println(list);
		
		list.removeLastOccurrence(30);
		System.out.println(list);
		
		
	}

}
