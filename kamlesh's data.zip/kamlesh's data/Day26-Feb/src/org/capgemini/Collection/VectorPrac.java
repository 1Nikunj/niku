package org.capgemini.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;



public class VectorPrac {

	public static void main(String[] args) {
	
		Vector<String> vector=new Vector<>();
		vector.add("Tom");
		vector.add("Tom");
		vector.add("Jerry");
		vector.add("Tom");
		vector.add("Jack");
		vector.add("Rose");
		vector.add("Flower");
		vector.add("Me");
		vector.add("Tom");
		vector.add("Ram");
		vector.add("Sam");
		System.out.println(vector);
		
		Iterator <String> itr=vector.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		Enumeration <String> enums=vector.elements();
		while(enums.hasMoreElements())
			System.out.print(enums.nextElement()+"--->");
		
	
	}

}
