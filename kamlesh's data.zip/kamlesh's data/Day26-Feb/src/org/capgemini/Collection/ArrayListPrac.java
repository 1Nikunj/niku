package org.capgemini.Collection;

import java.util.ArrayList;
import java.util.List;

public class ArrayListPrac {

	public static void main(String[] args) {

		
		List<String> mylist=new ArrayList<>();
		
		mylist.add("Om");
		mylist.add("jai");
		mylist.add("jaggu");
		mylist.add("null");
		//mylist.add(null);
		mylist.add("tom");
		mylist.add("jerry");
		mylist.add("Om");
		mylist.add("jai");

		
		
		
		System.out.println(mylist);
		
		System.out.println(mylist.size());
		System.out.println();
		System.out.println(mylist.contains("jai"));
		System.out.println(mylist.containsAll(mylist));
		System.out.println(mylist.get(5));
		System.out.println(mylist.isEmpty());
		System.out.println(mylist.indexOf("jai"));
		System.out.println(mylist.lastIndexOf("null"));
		//System.out.println(mylist.listIterator(5));
		
		System.out.println(mylist.set(3, "sonu"));
		System.out.println(mylist);
		
		System.out.println(mylist.retainAll(mylist));
		
		System.out.println("sublist:"+mylist.subList(1, 6));
		System.out.println(mylist);
	
	
	}
		
	
		
		
	}
	/*while(mylist.hasNext()){
		String str=mylist.next();
		if(str.equals("sonu"))
			litr.set("monu");
		
		System.out.println(str+"");
			
		}*/
