package org.capgemini.pracPOJO;

public class Validation {

	
public static boolean isValidEmpId(String EmpId){
		//return EmpId.matches("\\d{5}_[F|I|T][S]");
	return EmpId.matches("\\d{4}");
	}
public static boolean isValidKinid(String kinId){
		return kinId.matches("\\d{5}_[F|I|T][S]");
	}
		
public static boolean isValidFirstName(String firstName){
			return firstName.matches("[A-Z][a-z]+");
	}

public static boolean isvalidLastName(String lastName){
		return lastName.matches("[A-Z][a-z]+");

}
	
}
