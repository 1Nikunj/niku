package org.capgemini.pracPOJO;
import java.util.Scanner;

public class UserInteraction {
	
	public Employee getEmployee(){
		
	 String empId;
	 String kinId;
	 String firstName;
	 String lastName;
	 String address;
	 String emailId;
	 String mobNo;
	 String dob; 
	 String doj;
	
	Employee employee=new Employee();
	
	Scanner sc=new Scanner(System.in);
	boolean flag;
	
	
	do{
		
		System.out.println("Enter EmpID:");
		empId=sc.next();
		
		flag=Validation.isValidEmpId(empId);
		if(!flag)
			System.out.println("InValid EinId. Please try Again!");
		
	}while(!flag);
	
	
	do{
		
		System.out.println("Enter KinID:");
		kinId=sc.next();
		
		flag=Validation.isValidKinid(kinId);
		if(!flag)
			System.out.println("InValid KinId. Please try Again!");
		
	}while(!flag);


	do{
		System.out.println("Enter First Name:");
		firstName=sc.next();
		
		flag=Validation.isValidFirstName(firstName);
		if(!flag)
			System.out.println("InValid Name. Please try Again!");
		
	}while(!flag);
	

	do{
		System.out.println("Enter Last Name:");
		lastName=sc.next();

		flag=Validation.isvalidLastName(lastName);
		if(!flag)
			System.out.println("InValid Name. Please try Again!");

	}while(!flag);

	return employee;
}
}
