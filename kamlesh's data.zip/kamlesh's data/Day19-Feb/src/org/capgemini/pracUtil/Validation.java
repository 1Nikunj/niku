package org.capgemini.pracUtil;

public class Validation {

public static boolean isValidEmpId(String EmpId){
		//return EmpId.matches("\\d{5}_[F|I|T][S]");
	return EmpId.matches("\\d{1000-9999}");
	}
public static boolean isValidKinid(String kinId){
		return kinId.matches("\\d{5}_[F|I|T][S]");
	}
		
public static boolean isValidFirstName(String firstName){
			return firstName.matches("[A-Z][a-z]+");
	}

public static boolean isvalidLastName(String lastName){
		return lastName.matches("[A-Z][a-z]+");

}
public static boolean isvalidAddress(String address){
	return address.matches("\\d{3}+\\s+([a-zA-Z]+\\s[\\ #-/]+)");
}

public static boolean isvalidEmail(String emailId){
	return emailId.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
}

public static boolean isvalidMobileNo(String mobNo){
	return mobNo.matches("\\d{10}");
}

public static boolean isvalidDOB(String dob){
	
	
	
	
	
	
	return dob.matches("MM/dd/yyyy");

}
public static boolean isvalidDOJ(String doj){
	return doj.matches("MM/dd/yyyy");
}
}