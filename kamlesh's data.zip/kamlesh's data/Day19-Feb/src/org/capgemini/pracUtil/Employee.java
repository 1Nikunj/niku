package org.capgemini.pracUtil;

import java.util.Scanner;
import java.util.Date;


public class Employee {

	private String empId;
	private String kinId, firstName, lastName;
	private String address;
	private String emailId, mobNo;
	
	String dob; 
	String doj;	
	
	
public void getDetails(){
		Scanner sc=new Scanner(System.in);
		boolean flag;
		
		
		do{
			
			System.out.println("Enter EmpID:");
			empId=sc.next();
			
			flag=Validation.isValidEmpId(empId);
			if(!flag)
				System.out.println("InValid EinId. Please try Again!");
			
		}while(!flag);
		
		
		do{
			
			System.out.println("Enter KinID:");
			kinId=sc.next();
			
			flag=Validation.isValidKinid(kinId);
			if(!flag)
				System.out.println("InValid KinId. Please try Again!");
			/*if(Validation.isValidKinid(kinId)){
				System.out.println("Valid Id");
			}else
				System.out.println("InValid Id");*/
		}while(!flag);
	

		do{
			System.out.println("Enter First Name:");
			firstName=sc.next();
			
			flag=Validation.isValidFirstName(firstName);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
			
		}while(!flag);
		
	
		do{
			System.out.println("Enter Last Name:");
			lastName=sc.next();
	
			flag=Validation.isvalidLastName(lastName);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
	
		}while(!flag);

		do{
			System.out.println("Enter Address:");
			address=sc.next();
	
			flag=Validation.isvalidAddress(address);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
	
		}while(!flag);

		
		do{
			System.out.println("Enter EmailId:");
			emailId=sc.next();
	
			flag=Validation.isvalidEmail(emailId);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
	
		}while(!flag);

		
		do{
			System.out.println("Enter Mobile Number:");
			mobNo=sc.next();
	
			flag=Validation.isvalidMobileNo(mobNo);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
	
		}while(!flag);

		
		
		do{
			System.out.println("Enter Date of Birth:");
			dob=sc.next();
	
			flag=Validation.isvalidDOB(dob);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
	
		}while(!flag);

		
		do{
			System.out.println("Enter Date of Joining:");
			doj=sc.next();
	
			flag=Validation.isvalidDOJ(doj);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
	
		}while(!flag);

		
		
		
		
}
	
	public void printEmployee(){
		System.out.println(empId+"\n"+kinId +"\n"+ firstName+"\n"+lastName+"\n"+ address+"\n"+ emailId+"\n"+ mobNo+"\n"+ dob+"\n"+doj);
	}
	
	
	
}
