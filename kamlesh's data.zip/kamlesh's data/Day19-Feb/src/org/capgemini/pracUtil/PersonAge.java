package org.capgemini.pracUtil;
import java.util.Scanner;
import java.util.Date;
import java.util.Calendar;


public class PersonAge {
		
	
public void PersonAge(){
		
	Date myDate=new Date();
		
	System.out.println(myDate);
		String str;
		
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Date of Birth:");
		str=sc.next();
		
		Date date2=new Date(str);
		System.out.println(date2);
		//Date date=new Date(myDate.getYear() - date2.getYear()-1900, myDate.getMonth() - date2.getMonth()-1, myDate.getDay() - date2.getDay());
		
		int year=myDate.getYear() - date2.getYear();
		int month=myDate.getMonth() - date2.getMonth();
		if(month<0)
		{
			year--;
			System.out.println(0-month+"  "+year);
		}
		else
		{
		System.out.println(month+"  "+year);
		}
		}
	}
	

