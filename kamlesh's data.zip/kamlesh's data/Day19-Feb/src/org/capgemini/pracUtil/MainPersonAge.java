package org.capgemini.pracUtil;
import java.util.Scanner;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;



public class MainPersonAge {

	public static void main(String[] args) {
		
		PersonAge pa=new PersonAge();
	
		pa.PersonAge();
		
	}
}
