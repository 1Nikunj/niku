package org.capgemini.pracUtil;
import java.util.Date;


public class MainEmployee {

	public static void main(String[] args) {
		Employee employee=new Employee();
		employee.getDetails();
		employee.printEmployee();
		
		Date myDate=new Date();
		
		
		
	}

}
