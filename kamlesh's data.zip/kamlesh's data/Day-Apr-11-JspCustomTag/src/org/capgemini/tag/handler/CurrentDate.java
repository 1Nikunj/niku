package org.capgemini.tag.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CurrentDate extends SimpleTagSupport{

	
	 private String myFormat;
	  
	  
	public String getMyFormat() {
		return myFormat;
	}

	public void setMyFormat(String myFormat) {
		this.myFormat = myFormat;
	}




@Override
	public void doTag() throws JspException, IOException 
		{
			JspWriter out=getJspContext().getOut();
			if(myFormat==null)
			out.println(new Date());
			else{
				SimpleDateFormat sf=new SimpleDateFormat(myFormat);
			out.println(sf.format(new Date()));
			}

		} 
	 
	 
	
}
