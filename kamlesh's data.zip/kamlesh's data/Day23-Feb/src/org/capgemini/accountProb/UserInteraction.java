package org.capgemini.accountProb;


import java.util.Date;
import java.util.Scanner;

public class UserInteraction {
	public Account getAccountDetails()
	{	Account account =new Account();
		Address address=new Address();
		String id,pincode,balance;
		boolean flag=false;
		String accountname,doorno,streetname,city,state,opendate;
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("Enter account id");
			id=sc.next();
			flag=Validation.isValidAccountId(id);
		}while(flag);
		account.setAccountId(id);
		do{
			System.out.println("Enter account name");
			accountname=sc.next();
			flag=Validation.isValidAccountName(accountname);
		}while(flag);
		account.setAccountName(accountname);
		do{
			System.out.println("Enter open date");
			opendate=sc.next();
			flag=Validation.isValidOpenDate(opendate);
		}while(flag);
		Date openDate=new Date(opendate);
		account.setOpenDate(openDate);
		do{
			System.out.println("Enter balance");
			balance=sc.next();
			flag=Validation.isValidBalance(balance);
		}while(flag);
		account.setBalance(balance);
		System.out.println("Enter Address");
		System.out.println("Enter door no");
		doorno=sc.next();
		address.setDoorNo(doorno);
		System.out.println("Enter street name");
		streetname=sc.next();
		address.setStName(streetname);
		do{
			System.out.println("Enter city");
			city=sc.next();
			flag=Validation.isValidCity(city);
		}while(flag);
		address.setCity(city);
			
		do{
			System.out.println("Enter state");
				state=sc.next();
				flag=Validation.isValidState(state);
		}while(flag);
		address.setState(state);
		do{
			System.out.println("Enter pincode");
			pincode=sc.next();
			flag=Validation.isValidPin(pincode);
		}while(flag);
		address.setPinCode(pincode);
		account.setAddress(address);
		return account;
	}
	public void showAccountDetails(Account account)
	{
		Address address=new Address();
		address=account.getAddress();
		System.out.println(account.getAccountId()+"\t\t"+account.getAccountName()+"\t\t"+account.getOpenDate()+"\t\t"+account.getBalance()+"\t\t"+address.getDoorNo()+"\t"+address.getStName()+"\t"+address.getCity()+"\t"+address.getState()+"\t"+address.getPinCode());
		
	}

}
