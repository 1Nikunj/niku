package org.capgemini.accountProb;


public interface AccountDAO {
		void SaveAccount(Account account);
		void listAllAccounts();

	}

