package org.capgemini.accountProb;


import java.util.Date;

public class Account {
			private String accountId;
			private String accountName;
			private Date openDate;
			private String balance;
			Address address;
			public Account()
			{
				
			}
			public String getAccountId() {
				return accountId;
			}
			public void setAccountId(String accountId) {
				this.accountId = accountId;
			}
			public String getAccountName() {
				return accountName;
			}
			public void setAccountName(String accountName) {
				this.accountName = accountName;
			}
			public Date getOpenDate() {
				return openDate;
			}
			public void setOpenDate(Date openDate) {
				this.openDate = openDate;
			}
			public String getBalance() {
				return balance;
			}
			public void setBalance(String balance) {
				this.balance = balance;
			}
			public Address getAddress() {
				return address;
			}
			public void setAddress(Address address) {
				this.address = address;
			}
			

	}

