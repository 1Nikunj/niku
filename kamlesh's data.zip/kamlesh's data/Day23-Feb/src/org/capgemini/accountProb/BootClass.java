package org.capgemini.accountProb;


import java.util.Scanner;

public class BootClass {

	public static void main(String[] args) {
		AccountDAOImplementation adimp=new AccountDAOImplementation();
		int option;
		String ch;
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("1.Save Account");
			System.out.println("2.List all Accounts");
			System.out.println("Enter your option");
			option=sc.nextInt();
			if(option==1)
			{ 
				UserInteraction ui=new UserInteraction();
				Account account=new Account();
				account=ui.getAccountDetails();
				adimp.SaveAccount(account);;
								
			}
			else if(option==2)
			{
			
				adimp.listAllAccounts();;
			}
			System.out.println("Do you want to continue(y/n)");
			ch=sc.next();
			
		}while(ch.charAt(0)=='y'||ch.charAt(0)=='Y');
	}

}

