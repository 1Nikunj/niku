package org.capgemini.accountProb;


public class AccountDAOImplementation implements AccountDAO {

	Account [] accounts;
	int index=0;
	public AccountDAOImplementation()
	{
		accounts=new Account[50];
	}
	@Override
	public void SaveAccount(Account account) {
		accounts[index]=account;
		index++;
	}
	@Override
	public void listAllAccounts() {
		UserInteraction ui=new UserInteraction();
		System.out.println("Account Id\t\tAccount Name\t\tOpen Date \t\tBalance \t\tAddress");
		for(int i=0;i<index;i++)
		{
			ui.showAccountDetails(accounts[i]);
		}
	}

	
}
