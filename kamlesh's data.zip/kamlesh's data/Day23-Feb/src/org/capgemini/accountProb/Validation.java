package org.capgemini.accountProb;

public class Validation {


	public static boolean isValidAccountId(String id)
	{
		return id.matches("//d{15}");
	}
	public static boolean isValidAccountName(String name)
	{
		return name.matches("[A-Z][a-z]+");
	}
	public static boolean isValidOpenDate(String date)
	{
		return date.matches("[0123][0-9]-[jan|feb|mar|apr|jun|july|aug|sep|oct|nov|dec]-[12][890][0-9][0-9]");
	}
	public static boolean isValidCity(String id)
	{
		return id.matches("[A-Z][a-z]+");
	}
	public static boolean isValidState(String id)
	{
		return id.matches("[A-Z][a-z]+");
	}
	public static boolean isValidPin(String id)
	{
		return id.matches("//d{6}");
	}
	public static boolean isValidBalance(String id)
	{

		int number;
		number=Integer.parseInt(id);
		if(number>=500)
			return false;
		return true;
	}
}




