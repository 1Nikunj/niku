package org.capgemini.exception;

public class InvalidSalaryException  extends Exception{
	
	public InvalidSalaryException(String msg){
		super(msg);
	}

}
