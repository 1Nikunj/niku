package org.capgemini.exception;
import java.util.Scanner;



public class EmployeeMain {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		
		Employee emp=new Employee();
		
		System.out.println("Enter Employee Id:");
		int eid=sc.nextInt();
		emp.setEmpId(eid);
		
		System.out.println("Enter Employee Name:");
		String ename=sc.next();
		emp.setEmpName(ename);
		
		System.out.println("Enter Employee Salary:");
		double salary=sc.nextDouble();
		
		
		try{
		if(Validation.isValidSalary(salary))
			emp.setSalary(salary);
		}catch(InvalidSalaryException ex){
			System.out.println(ex.getMessage());
		}
		
		
		System.out.println(emp);
		
	}
		
		
}


