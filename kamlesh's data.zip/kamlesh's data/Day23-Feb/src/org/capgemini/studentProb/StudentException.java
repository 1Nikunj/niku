package org.capgemini.studentProb;

public class StudentException extends Exception{
	public StudentException(String msg)
	{
		super(msg);
	}
	@Override
	public String getMessage(){
		return "Maximum of 10 students";
	}

}
