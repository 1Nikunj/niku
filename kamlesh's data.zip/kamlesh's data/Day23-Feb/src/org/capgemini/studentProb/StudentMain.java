package org.capgemini.studentProb;

import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) throws NullPointerException{
		Student[] students=new Student[10];
		Scanner sc=new Scanner(System.in);
		int index=0;
		try{
			if(index>=10)
			{
				throw new StudentException("More than 10 students");
			}
			else{
		while(index<10)
		{
			System.out.println("Enter name of student");
			String name=sc.next();
			System.out.println("Enter roll number of student");
			int roll=sc.nextInt();
			students[index].setName(name);
			students[index].setRollNo(roll);
			index++;
		}}}
		catch(StudentException se)
		{
			System.out.println(se.getMessage());
		}
	}

}
