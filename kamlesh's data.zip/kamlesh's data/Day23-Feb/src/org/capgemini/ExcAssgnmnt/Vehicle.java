package org.capgemini.ExcAssgnmnt;

import java.util.*;
public class Vehicle  {
	
	
	int vid;
	String vname;
	String direction;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			
			Vehicle V = new Vehicle();
			
			System.out.println("Enter the vid:");
			Scanner sc = new Scanner(System.in);
			V.vid = sc.nextInt();
			
			System.out.println("Enter the vehicle name:");
			V.vname=sc.next();
			
			
			System.out.println("Enter the vehicles direction :");
			V.direction=sc.next();
			
		
			if(V.direction.equals("same"))
			{
				throw new InvalidVehicleException ("Direction should be different else vehicle will collide");
				
			}
			
		
			
		}
		catch(Exception e)
		{
			
			System.out.println(e.getMessage());
		}
		
			

	}

}
