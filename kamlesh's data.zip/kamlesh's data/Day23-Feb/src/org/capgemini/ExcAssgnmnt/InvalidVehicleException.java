package org.capgemini.ExcAssgnmnt;

import java.util.*;

public class InvalidVehicleException extends RuntimeException {
	
	public InvalidVehicleException(String arg)
	{
		
		super(arg);
		
			
	}

}
