package org.capgemini.ExcAssgnmnt;

public class StudentMain {

	public static void main(String[] args) {

		
		int i = 0;
		
		try
		{
			Student S[] = new Student[10];
			for(i=0;i<2;i++)
			{
				
				S[i].getdata();
			    S[i].display();
			}
			
		}
		catch(ArrayIndexOutOfBoundsException e )
		{
			System.out.println(e.getMessage());
			
		}

	}

}
