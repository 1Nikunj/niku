package org.capgemini.ExcAssgnmnt;

import java.util.*;

public class Student {
	
	int rollno;
	String name;
	
	void getdata()
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the rollno:");
		rollno = sc.nextInt();
		
		System.out.println("Enter the name:");
		name = sc.next();	
		
		
	}
	
	void display()
	{
		
		System.out.println(rollno+""+name);
	}

}
