package org.capgemini.ExcAssgnmnt;


public class InvalidException extends Exception {
	
	
	
	public InvalidException(String arg)
	{
		
		super(arg);
		
	}

}

