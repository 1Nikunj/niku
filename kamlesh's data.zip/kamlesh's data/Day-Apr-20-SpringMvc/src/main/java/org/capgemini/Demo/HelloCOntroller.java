package org.capgemini.Demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloCOntroller {
	
	

	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		String message="Welcome to the World of Spring MVC";
		
		//1->View page Name
		//2-->Model object name
		//3-->Model Object
		
		return new ModelAndView("helloPage","msg",message);
		
		
		
	}

}
