package org.capgemini.ServletDemo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out= response.getWriter();
		
		out.println("Login Page!!!<br><br>");
		
		
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upwd");
		out.println("Username:" + userName +"<br>");
		out.println("Userpassword:" + userPwd +"<br>");
		
		
		if(userName.equals("niki")&&userPwd.equals("niki123"))
			response.sendRedirect("pages/success.html");
		else
			response.sendRedirect("pages/login.html");
		
		
	}

}
