package org.cap.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.cap.pojo.Account;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AccountController {

	
	@RequestMapping("/accountForm")
	public String showAccountForm(Map<String, Object> maps){
		
		
		maps.put("account", new Account());
		maps.put("accounts", getAllAccountTypes());
		
		return "accountForm";
	}
	
  	@RequestMapping(value="/showAccount",method=RequestMethod.POST)
	public ModelAndView showAccountDetails(@Valid @ModelAttribute("account") Account acc,
			BindingResult result){
		if(result.hasErrors())
			return new ModelAndView("accountForm","accounts", getAllAccountTypes());
		else			
		{		
		System.out.println(acc);
		return new ModelAndView("showAccount","accounts", getAllAccountTypes());
		}
	}
	
	
	/*public List<String> getAllAccountTypes(){
		
		List<String> accoutType=new ArrayList<String>();
		
		accoutType.add("Saving");
		accoutType.add("Current");
		accoutType.add("Loan");
		accoutType.add("Rrcurring Deposit");
		accoutType.add("Fixed Deposit");
		
		return accoutType;
	}
	
	*/
	
  	
public Map<Integer,String> getAllAccountTypes(){
		
	Map<Integer, String> maps=new HashMap<>();
		
		maps.put(1,"Saving");
		maps.put(2,"Current");
		maps.put(3,"Loan");
		maps.put(4,"Rrcurring Deposit");
		maps.put(5,"Fixed Deposit");
		
		return maps;
}
}
