package org.cap.pojo;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.Past;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;



public class Account {
	
	@Min(value=15,message="* Account Number should be a 15 digit number")
	private int account_no;
	
	@NotEmpty(message="* Please enter AccountName.")		
	private String accountName;
	
	@Future(message="* Opening date must be Current date or Future date.")
	private Date openingDate;
	
	private String accountType;
	
	@Range(min=500,max=300000,message="* Amount should be between 500 to 3lakcs.")
	private double amount;
	
	@Past(message="* DOB must be past date.")
	private Date dob;
	
	private String gender;
	
	
	public Account(){}


	public Account(int account_no, String accountName, Date openingDate, String accountType, double amount, Date dob,
			String gender) {
		super();
		this.account_no = account_no;
		this.accountName = accountName;
		this.openingDate = openingDate;
		this.accountType = accountType;
		this.amount = amount;
		this.dob = dob;
		this.gender = gender;
	}


	public int getAccount_no() {
		return account_no;
	}


	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public Date getOpeningDate() {
		return openingDate;
	}


	public void setOpeningDate(Date openingDate) {
		this.openingDate = openingDate;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	@Override
	public String toString() {
		return "Account [account_no=" + account_no + ", accountName=" + accountName + ", openingDate=" + openingDate
				+ ", accountType=" + accountType + ", amount=" + amount + ", dob=" + dob + ", gender=" + gender + "]";
	}
	
	
	
}
