package org.capgemini.Dao;

import java.util.List;

import javax.sql.DataSource;

import org.capgemini.Demo.Address;
import org.capgemini.Demo.Visitor;

import javax.sql.DataSource;


public interface IVisitorDao {
	
	public void setDataSource(DataSource dataSource);
	
	public void addVisitor(Visitor visitor, Address address);
	
	public void deleteVisitor(int visitorId);
	
	public void showAll();
	
	public void searchVisitor(int visitorId);
}

