package org.capgemini.Demo;



public class Address {
	private int address_Id;
	private int doorNo;
	private String StName;
	private String city;
	private String state;
	private int visitor_Id;

public Address() {}

public Address(int address_Id, int doorNo, String stName, String city, String state,int visitor_Id) {
	super();
	this.address_Id = address_Id;
	this.doorNo = doorNo;
	StName = stName;
	this.city = city;
	this.state = state;
	this.visitor_Id = visitor_Id;
}
public int getAddress_Id() {
	return address_Id;
}
public void setAddress_Id(int address_Id) {
	this.address_Id = address_Id;
}
public int getDoorNo() {
	return doorNo;
}
public void setDoorNo(int doorNo) {
	this.doorNo = doorNo;
}
public String getStName() {
	return StName;
}
public void setStName(String stName) {
	StName = stName;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public int getVisitor_Id() {
	return visitor_Id;
}
public void setVisitor_Id(int visitor_Id) {
	this.visitor_Id = visitor_Id;
}

@Override
public String toString() {
	return "Address [address_Id=" + address_Id + ", doorNo=" + doorNo + ", StName=" + StName + ", city=" + city
			+ ", state=" + state + ", visitor_Id=" + visitor_Id + "]";
}

}
