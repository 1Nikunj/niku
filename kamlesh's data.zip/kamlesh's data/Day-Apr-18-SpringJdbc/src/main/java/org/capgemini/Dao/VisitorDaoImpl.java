package org.capgemini.Dao;

import java.util.List;

import org.capgemini.Demo.Address;
import org.capgemini.Demo.AddressRow;
import org.capgemini.Demo.Visitor;
import org.capgemini.Demo.VisitorRow;
import org.springframework.jdbc.core.JdbcTemplate;
import javax.sql.DataSource;



public class VisitorDaoImpl implements IVisitorDao {

	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
		
	}

	public void addVisitor(Visitor visitor,Address address) {
		String sql="insert into visitor values(?,?)";
		String sql1="insert into address values(?,?,?,?,?,?)";
		System.out.println(visitor);
		System.out.println(address);
		
		jdbcTemplate.update(sql,new Object[]{visitor.getVisitor_Id(),visitor.getVisitor_Name()});
		
		jdbcTemplate.update(sql1,new Object[]{address.getAddress_Id(),address.getDoorNo(),address.getStName(),address.getCity(),address.getState(),visitor.getVisitor_Id()});
		
	}

	public void deleteVisitor(int visitorId) {
		String sql="delete from visitor where visitor_Id=?";
		String sql1="delete from address where visitor_Id=?";
		jdbcTemplate.update(sql,visitorId);
		
		jdbcTemplate.update(sql1,visitorId);
		
	}
	
	public void showAll()
	{
	//String sql="select * from visitor,address where visitor.visitor_Id=address.visitor_Id";
		String sql="select * from visitor";
		String sql1="select * from address";
		List<Visitor> visitors= jdbcTemplate.query(sql, new VisitorRow());
		List<Address> addresses=jdbcTemplate.query(sql1, new AddressRow());

		for(Visitor visitor:visitors)
		{
			System.out.print(visitor);
		for(Address address:addresses)
		{
			if(visitor.getVisitor_Id()==address.getVisitor_Id())
			System.out.println(address);
		}
	}
	}

	public void searchVisitor(int visitorId) {
		String sql="select * from visitor where visitor_Id=?";
		String sql1="select * from address where visitor_Id=?";
		Visitor visitor=jdbcTemplate.queryForObject(sql, new Object[]{visitorId},new VisitorRow());
			Address address=jdbcTemplate.queryForObject(sql1, new Object[]{visitorId},new AddressRow());
			if(visitor!=null)
			{
			System.out.println("Visitor_Id\tVisitorName\tAddressId\tDoor no.\tStreet name\tCity\tState ");
			System.out.println(visitor.getVisitor_Id()+"\t"+visitor.getVisitor_Name()+"\t"+address.getAddress_Id()+"\t"+address.getDoorNo()+"\t"+address.getStName()+"\t"+address.getCity()+"\t"+address.getState());
			}
			else
				System.out.println("Visitor not found");


		}

}

