package org.capgemini.Demo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
public class AddressRow implements RowMapper<Address> {

	public Address mapRow(ResultSet rs, int count) throws SQLException {
		Address address=new Address();
		address.setAddress_Id(rs.getInt(1));
		address.setDoorNo(rs.getInt(2));
		address.setStName(rs.getString(3));
		address.setCity(rs.getString(4));
		address.setState(rs.getString(5));
		address.setVisitor_Id(rs.getInt(6));
		return address;
	}

}
