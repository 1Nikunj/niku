package org.capgemini.Demo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
public class VisitorRow implements RowMapper<Visitor> {

	public Visitor mapRow(ResultSet rs, int count) throws SQLException {
		
		Visitor visitor=new Visitor();
		visitor.setVisitor_Id(rs.getInt(1));
		visitor.setVisitor_Name(rs.getString(2));
	
		return visitor;
	}

}
