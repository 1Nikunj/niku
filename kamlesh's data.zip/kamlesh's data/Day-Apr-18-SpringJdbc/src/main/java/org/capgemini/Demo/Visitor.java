package org.capgemini.Demo;



public class Visitor {

	private int visitor_Id;
	private String visitor_Name;
	private Address address;
	
	
	public Visitor() {}
	
	
	
	public Visitor(int visitor_Id, String visitor_Name, Address address) {
		super();
		this.visitor_Id = visitor_Id;
		this.visitor_Name = visitor_Name;
		this.address = address;
	}



	public int getVisitor_Id() {
		return visitor_Id;
	}
	public void setVisitor_Id(int visitor_Id) {
		this.visitor_Id = visitor_Id;
	}
	public String getVisitor_Name() {
		return visitor_Name;
	}
	public void setVisitor_Name(String visitor_Name) {
		this.visitor_Name = visitor_Name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Visitor [visitor_Id=" + visitor_Id + ", visitor_Name=" + visitor_Name +"]";
	}
	
}
