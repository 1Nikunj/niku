package org.capgemini.Demo;

import java.util.Scanner;

import org.capgemini.Dao.IVisitorDao;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {
	public static void main(String[] args) {
		
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("jdbcBean.xml");
		Visitor visitor=new Visitor();
		Address address=new Address();
		IVisitorDao visitordao= (IVisitorDao) context.getBean("jdbcTemp");
		int choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Add visitor");
		System.out.println("2. View All visitors");
		System.out.println("3. delete visitor");
		System.out.println("4. Search visitor");
		System.out.println("5. Update visitor");
		
		System.out.println("Enter your choice");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter visitor id:");
			visitor.setVisitor_Id(sc.nextInt());
			System.out.println("Enter name");
		visitor.setVisitor_Name(sc.next());
		System.out.println("Enter address id:");
		address.setAddress_Id(sc.nextInt());
		System.out.println("Enter door number");
		address.setDoorNo(sc.nextInt());
		System.out.println("Enter street name");
		address.setStName(sc.next());
		System.out.println("Enter city");
		address.setCity(sc.next());
		System.out.println("Enter state:");
		address.setState(sc.next());
		visitordao.addVisitor(visitor,address);
				
			break;
			
		case 2:
			visitordao.showAll();
			break;
			
		case 3:
			System.out.println("Enter visitor id:");
			int visitorId=sc.nextInt();
			visitordao.deleteVisitor(visitorId);
			
			break;
			
		case 4:
			System.out.println("Enter Visitor id");
			int visitorId1=sc.nextInt();
			visitordao.searchVisitor(visitorId1);
			break;
			
		case 5:
			
			break;
			
			default:
				
				break;
		
		}
		
}

}
