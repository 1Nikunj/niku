package org.capgeimini.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Encrypt {

	public static void main(String[] args) throws IOException {
			
		File file=new File("D:\\kjangade\\myFolder\\mytext.txt");
			FileReader fileReader=null;
			try {
				fileReader=new FileReader(file);
			} catch (FileNotFoundException e) {
			
				e.printStackTrace();
			}
			long size=file.length();
			char str[] = new char[50];
			while(size>0)
			{
				char ch=(char)fileReader.read();
				if(ch=='a')
					System.out.print('z');
				else if(ch=='i')
					System.out.print(":a");
				else if(ch=='e')
					System.out.print('!');
				else if(ch=='n')
					System.out.print('k');
				else
					System.out.print(ch);
							
				
			}
			fileReader.close();
		}

	}
