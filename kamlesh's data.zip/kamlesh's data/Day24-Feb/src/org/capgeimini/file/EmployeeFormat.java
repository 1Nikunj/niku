package org.capgeimini.file;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import java.util.Scanner;

public class EmployeeFormat {

	public static void main(String[] args) {
		

		int empId=0;
		String empName="null";
		double salary=0;
		boolean isPermanent=true;
		String gender="null";
		
		Scanner sc=new Scanner(System.in);
		
		File file=new File("D:\\kjangade\\myFolder\\employeeTable.txt");
		
		FileOutputStream fout=null;
		DataOutputStream dout=null;
		try{
			fout=new FileOutputStream(file);
			dout=new DataOutputStream(fout);
			
			
			
			System.out.println("Enter Employee Id:");
			empId=sc.nextInt();
			System.out.println("Enter Employee name:");
			empName=sc.next();
			System.out.println("Enter Salary:");
			salary=sc.nextDouble();
			System.out.println("Enter Employee is permanent or not:");
			isPermanent=sc.nextBoolean();
			System.out.println("Enter Gender:");
			gender=sc.next();
			
			
			System.out.print("Employee Id:" +empId + "\nEmployee Name :" + empName +
					"\nSalary :" + salary +
					"\nIs Permenant: " + isPermanent +
					"\nGender :" + gender);
			
			
			
			dout.writeInt(empId);
			dout.writeChars(empName);
			dout.writeChars(gender);
			dout.writeDouble(salary);
			dout.writeBoolean(isPermanent);
			
				
			
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			try{
			dout.close();
			fout.close();
			}catch(IOException ex){
				ex.printStackTrace();
			}
			
		}
		
		
		
	}

}
