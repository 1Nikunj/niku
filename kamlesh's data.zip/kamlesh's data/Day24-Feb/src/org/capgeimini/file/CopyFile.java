package org.capgeimini.file;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyFile {

	public static void main(String[] args) throws IOException {
		File file1=new File("D:\\kjangade\\myFolder\\mytext.txt");
		File file2=new File("D:\\kjangade\\myFolder\\Copyfile.txt");
		
		FileReader fileReader=new FileReader(file1);
		FileWriter fileWriter=new FileWriter(file2);
		
		long size=file1.length();
		while(size>0)
		{
			fileWriter.write((char)fileReader.read());
			size--;
		
		}
		fileWriter.close();
		fileReader.close();
		
	}

}
