package org.capgeimini.file;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Employee {

	public static void main(String[] args) throws IOException  {
		File file=new File("D:\\kjangade\\myFolder\\Employee List.txt");
	
		Scanner sc=new Scanner(System.in);
		int ch,id;
		char gender;
		boolean isPermanent;
		double salary;
		String eName;
		FileOutputStream fout=new FileOutputStream(file,true);;
		DataOutputStream dout=new DataOutputStream(fout);;
		FileInputStream fin= new FileInputStream(file);;
		DataInputStream din=new DataInputStream(fin);
		int index=0;
		do{
			System.out.println("1.Enter Employee Details");
			System.out.println("2.Print all employee Details");
			System.out.println("Enter your Choice");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1: try {
					
					System.out.println("Enter emp id");
					id=sc.nextInt();
					System.out.println("Enter gender");
					gender=sc.next().charAt(0);
					System.out.println("Is permanent or not (True or False)");
					isPermanent=sc.nextBoolean();
					System.out.println("Enter Salary");
					salary=sc.nextDouble();
					System.out.println("Enter employee name");
					eName=sc.next();
					dout.writeInt(id);
					dout.writeChar(gender);
					dout.writeBoolean(isPermanent);
					dout.writeDouble(salary);
					dout.writeChars(eName);
					dout.writeChar('\n');
					index++;
					
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			finally{
				
				fout.close();
				dout.close();
			}
				break;
			case 2:
				try{
				for(int j=0;j<index;j++)
				{
				int eId=din.readInt();
				char gndr=din.readChar();
				boolean isP=din.readBoolean();
				double salarys=din.readDouble();
				String name=din.readLine();
				System.out.println(eId+"\t"+name+"\t"+gndr+"\t"+isP+"\t"+salarys);
				}
				}catch(FileNotFoundException e)
				{
					e.printStackTrace();
				}
				finally{
					fin.close();
					din.close();
				}
				break;
			}
			
		}while(ch==1||ch==2);
		
	}

}

