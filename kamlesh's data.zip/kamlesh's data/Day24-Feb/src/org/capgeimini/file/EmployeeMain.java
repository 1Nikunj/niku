package org.capgeimini.file;

import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		
	
	//void printMen()
	//{
			Scanner sc=new Scanner(System.in);
			System.out.println("Main Menu\n1.Save\n2.List\n3.Find\n4.Delete");
			System.out.println("Enter your choice");
			int ch=sc.nextInt();
	//}
}
}