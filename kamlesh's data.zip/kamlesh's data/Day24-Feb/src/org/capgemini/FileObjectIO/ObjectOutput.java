package org.capgemini.FileObjectIO;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class ObjectOutput {

		public static void main(String[] args) {
			File file=new File("D:\\kjangade\\myFolder\\employee.dat");

			
			//Write object into File System
			ObjectOutputStream objout=null;
			FileOutputStream fout=null;
			
			UserInteraction interaction=new UserInteraction();
			
			try{
				fout=new FileOutputStream(file);
				objout=new ObjectOutputStream(fout);
				
				Scanner sc=new Scanner(System.in);
				String choice;
				
				do{
					Employee emp=interaction.getEmployeeDetails();
					objout.writeObject(emp);
					System.out.println("Wish to enter more Employee?[y|n] : ");
					choice=sc.next();
				}while(choice.charAt(0)=='Y'||choice.charAt(0)=='y');
				
				
			}catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					objout.close();
					fout.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
			
			
			
			//Read object from File System
			FileInputStream fin=null;
			ObjectInputStream objin=null;
			try{
				fin=new FileInputStream(file);
				objin=new ObjectInputStream(fin);
				
				
				
				Employee emp=(Employee)objin.readObject();
				
				while(emp!=null){
					interaction.printEmployee(emp);
					emp=(Employee)objin.readObject();
				}
				
				
				
				
			}catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (EOFException e) {
				//e.printStackTrace();
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				try {
					objin.close();
					fin.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}

	

}
