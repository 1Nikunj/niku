package org.capgemini.practice6;

public class Employee {

	int empId=101;
	String empNAme="Tom";
	Weekdays holiday=Weekdays.SAT;
	
	
	public void printEmployee(){
		System.out.println(empId+","+empNAme+","+holiday);
		
		
	}
	public static void main(String[] args){
		Employee emp=new Employee();
		
		emp.printEmployee();
	}
	
}
