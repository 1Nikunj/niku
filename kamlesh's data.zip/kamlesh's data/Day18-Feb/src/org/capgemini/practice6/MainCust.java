package org.capgemini.practice6;

public class MainCust {

	public static void main(String[] args) {
		Customer cust=new Customer();
		cust.chooseCustType();
		cust.getCustDetail();
		cust.printCustDetail();
		
		
		/*CustType[] custType= CustType.values();
		
		for(CustType type : custType){
			System.out.println(type +"- " + type.getValue());
		}*/
		
	
	}

}
