package org.capgemini.practice6;

public enum CustType {

	SILVER(0,100),GOLD(101,300),PLATINUM(301,500),DIAMOND(501,1000);
	
	private int minValue;
	private int maxValue;
	
	
private CustType(int minValue,int maxValue){
		this.minValue=minValue;
		this.maxValue=maxValue;
	}
	
	public int getMinValue(){
		return minValue;
	}
	
	public int getMaxValue(){
		return maxValue;
	}
	

}

