package org.capgemini.practice6;
import java.util.Scanner;

public class Customer {

	int custId;
	String custName;
	
	double regFees;
	
	 CustType custType;
	
	
	public void chooseCustType(){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1.Silver");
		System.out.println("2.Gold");
		System.out.println("3.Platinum");
		System.out.println("4.Diamond");
		
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		
		switch(choice){
		case 1:
			
			custType=custType.SILVER;
				break;
			case 2:
				custType=custType.GOLD;
				break;
			case 3:
				custType=custType.PLATINUM;
				break;
			case 4:
				custType=custType.DIAMOND;
				break;
			
		}
		
	}
	
	public void getCustDetail(){
	
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter customer details:");
		System.out.println("enter customer id:");
		custId=sc.nextInt();
		
		System.out.println("enter customer name:");
		custName=sc.next();
		
		System.out.println("enter registration fees:");
		regFees=sc.nextDouble();
			
	}

	
	public void printCustDetail(){
		System.out.println("customer id:"+custId+" , " + "customer name:"+custName +" , "  + "registration fees:"+regFees +" , "+ "customer type:"+custType);
	}
	
	
	
}
	

