package org.capgemini.practice6;

public enum Weekdays {

	MON,TUE,WED,THU,FRI,SAT,SUN;
	
	
	
}
