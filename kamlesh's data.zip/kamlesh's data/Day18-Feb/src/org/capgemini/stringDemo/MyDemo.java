package org.capgemini.stringDemo;

public class MyDemo {

	public static void main(String[] args) {

		String str1="tom";
		String str2="tom";
		
		String mystr=new String ("tom");
		
		//System.out.println(str1==str2);
		
		//System.out.println(str1==mystr);
		
		
		System.out.println(str1.equals(str2));
		
		System.out.println(str1.equals(mystr));
	}

}
