package org.capgemini.stringDemo;

public class EncryptMain {

	public static void main(String[] args) {
	
		
		Encrypt enc=new Encrypt();
		
		enc.getString();
		enc.encryptString();
		
	}

}
