package org.capgemini.stringDemo;

public class MainFormat {

	public static void main(String[] args) {
		
		
		StringFormat p=new StringFormat();
				p.getString();
				p.printPattern();
			}

		}
