package org.capgemini.stringDemo;
import java.util.Scanner;

public class Encrypt {

		String string,tmp;
		char ch;
		int count=0;

public void getString(){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter string");
			string=sc.next();
		
		System.out.println("Enter character");
			tmp=sc.next();
			ch=tmp.charAt(0);
			
		}
		
public void encryptString(){
	
			for(int i=0;i<string.length();i++)
			{
				int ascii=(int)string.charAt(i);
				ascii=ascii-2;
				//tmp=tmp.concat((char)ascii);
				
				
			}
		}

}
