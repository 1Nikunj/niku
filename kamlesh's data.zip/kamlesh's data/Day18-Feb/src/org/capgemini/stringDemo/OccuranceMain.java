package org.capgemini.stringDemo;

public class OccuranceMain {

	public static void main(String[] args) {
		
				Occurance op=new Occurance();
				op.getString();
				op.countCharacter();
				op.printCount();
			
	}
}
