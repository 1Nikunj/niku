package org.capgemini.stringDemo;

public class MainTest {

	public static void main(String[] args) {

Employee emp=new Employee(1,"tom");
Employee emp1=new Employee(1,"tom");


System.out.println(emp==emp1);

System.out.println(emp.equals(emp1));


	}

}
