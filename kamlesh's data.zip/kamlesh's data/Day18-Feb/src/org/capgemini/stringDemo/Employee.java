package org.capgemini.stringDemo;

public class Employee {

	private int empid;
	private String empName;
	
	
	public Employee(){
		
		
		
	}
	
	public Employee(int empid,String empName){
		
		this.empid=empid;
		this.empName=empName;
		
	}
	
	
		
		
		
	}
	
	
