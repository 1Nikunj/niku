package org.capgemini.practiceString;

public class CharAtExample {

	public static void main(String[] args) {
		
			 
			String name="kamlesh";  
			char ch=name.charAt(3); //returns the char value at the 4th index  
			
			System.out.println(ch);  
			
	}
}


