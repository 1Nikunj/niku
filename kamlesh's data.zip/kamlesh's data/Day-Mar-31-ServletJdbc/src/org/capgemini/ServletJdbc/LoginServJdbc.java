package org.capgemini.ServletJdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServJdbc
 */
public class LoginServJdbc extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out= response.getWriter();
		//out.println("Login Page!!!<br><br>");
		
		
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upwd");
		String userEmail=request.getParameter("uemail");
		//out.println("Username:" + userName +"<br>");
		//out.println("Userpassword:" + userPwd +"<br>");
		

	try {
		Class.forName("com.mysql.jdbc.Driver");

		
		System.out.println("driver class loaded");


		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/servletjdbc","root","Pass1234");

		System.out.println("conection established");
		
		Statement stmt=con.createStatement();
		 
	
		//ResultSet rs=stmt.executeQuery("select UserName,PASSWORD from LoginDetail where email='kamlesh@capgemini.com'");
		//ResultSet rs=stmt.executeQuery("select UserName,PASSWORD from LoginDetail where email='akhil@gmail.com'");
		ResultSet rs=stmt.executeQuery("select * from LoginDetail");
		
		boolean flag=false;
		while(rs.next())
		{
			
			if(userName.equals(rs.getString(1))&& userPwd.equals(rs.getString(2))&& userEmail.equals(rs.getString(3)))
				{
					flag=true;
					response.sendRedirect("pages/success.html");
				}
			break;
		}
			if(flag==false)
				{
					response.sendRedirect("pages/login.html");
				}

		con.close();
		
	} catch (ClassNotFoundException | SQLException e) {
		
		e.printStackTrace();
	}
	


		
	}

}
