package org.capgemini.custAssignment;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CustomerDaoImp implements CustomerDao{
	
	List<Customer> mylst;
	public CustomerDaoImp()
	{
		mylst=new ArrayList<>();
	}
	@Override
	public void storeCustomer(Customer c) {
		
		mylst.add(c);
	}

	@Override
	public void listAllCustomers() {
		Iterator<Customer> itr=mylst.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next().toString());                              
		}
		
	}

	@Override
	public void searchCustomer(int custId) {
		Iterator<Customer> itr=mylst.iterator();
		while(itr.hasNext())
		{	Customer cus=itr.next();
			if(cus.getCustomer_id()                                                                                                                                                                                                                                                          ==custId)
				System.out.println(cus.toString());
		else
			System.out.println("Not found");
		}	
		}

}
