package org.capgemini.custAssignment;

public interface CustomerDao {

	
	public void storeCustomer(Customer c);
	public void listAllCustomers();
	public void searchCustomer(int custId);

}


