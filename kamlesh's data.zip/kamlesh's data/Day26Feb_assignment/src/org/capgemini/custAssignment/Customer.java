package org.capgemini.custAssignment;

import java.util.Date;

public class Customer {
//private fields
	private int customer_id;
	private  String customer_name;
	private double reg_fees;
	private Date reg_date;
	private String address;
	
//no args constructor
	public Customer(){
		
	}

//parameterized constructor
	public Customer(int customer_id, String customer_name, double reg_fees, Date reg_date, String address) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.reg_fees = reg_fees;
		this.reg_date = reg_date;
		this.address = address;
	}

//getters and setters
	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public double getReg_fees() {
		return reg_fees;
	}

	public void setReg_fees(double reg_fees) {
		this.reg_fees = reg_fees;
	}

	public Date getReg_date() {
		return reg_date;
	}

	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

//ToString mthd
	
	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_name=" + customer_name + ", reg_fees=" + reg_fees
				+ ", reg_date=" + reg_date + ", address=" + address + "]";
	}
	
}
