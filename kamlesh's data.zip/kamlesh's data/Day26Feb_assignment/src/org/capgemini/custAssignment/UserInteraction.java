package org.capgemini.custAssignment;

import java.util.Date;
import java.util.Scanner;


public class UserInteraction {

	
public Customer getCustomerDetails()
		{
				Customer cust=new Customer();
				 int customer_id;
				 String customer_name;
				 double reg_fees;
				 String date;
				 String address;
				
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter customer id");
				customer_id=sc.nextInt();
				System.out.println("Enter customer name");
				customer_name=sc.next();
				System.out.println("Enter Registration fees");
				reg_fees=sc.nextLong();
				System.out.println("Enter Registration date");
				date=sc.next();
				System.out.println("Enter address");
				address=sc.next();
				cust.setCustomer_id(customer_id);
				cust.setCustomer_name(customer_name);
				cust.setReg_fees(reg_fees);
				Date d=new Date(date);
				cust.setReg_date(d);
				cust.setAddress(address);
				return cust;
			
		}
		
}
