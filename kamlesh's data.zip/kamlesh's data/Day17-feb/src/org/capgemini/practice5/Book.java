package org.capgemini.practice5;
import java.util.Scanner;

public class Book {

	private int book_id;
	private String book_name;
	private String auther;
	private String publisher;
	private Double price;
	
	
	
	public Book getbookDetails(){
	
		Book book=new Book();
		
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("enter book id");
		book.book_id=sc.nextInt();
		
		System.out.println("enter book name");
		book.book_name=sc.next();
		
		System.out.println("enter auther name");
		book.auther=sc.next();
		
		System.out.println("enter publisher name");
		book.publisher=sc.next();
		
		System.out.println("enter price");
		book.price=sc.nextDouble();
		
		
		return book;
	
	}
	
	public void showBookDetail(){
		
		System.out.println("book id:"+book_id +"\t"+"book name:"+book_name+"\t" +"Auther name:"+auther+"\t" +"Publisher name:"+publisher+"\t" + "Price"+price);
		//System.out.println(bookId+"\t"+bookName+"\t"+author+"\t"+price);
		
	}
	
	
}
