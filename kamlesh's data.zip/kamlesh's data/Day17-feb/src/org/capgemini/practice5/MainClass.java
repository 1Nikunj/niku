package org.capgemini.practice5;

import java.util.Scanner;


public class MainClass {

	public static void main(String[] args) {
		
		
		Book book=new Book();
		BookDaoImplement bookdaoImpl=new BookDaoImplement();
		Scanner sc=new Scanner(System.in);
		
		String choice;
		
		do{
		
			System.out.println("1.save book");
			System.out.println("2. list all books");
			System.out.println("enter your choice:");
			
			int option=sc.nextInt();
			
		if(option==1){
			
			book=book.getbookDetails();
			bookdaoImpl.saveBook(book);
		}
		else
			
			if(option==2){
				
				bookdaoImpl.listAllBook();
			}
			System.out.println("Wish to Continue?[y|n]");
			choice=sc.next();
		
		}while(choice.charAt(0)=='Y'|| choice.charAt(0) =='y');
		
	}
	
}

