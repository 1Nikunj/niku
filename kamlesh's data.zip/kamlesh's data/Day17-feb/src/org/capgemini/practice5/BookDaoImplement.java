package org.capgemini.practice5;

public class BookDaoImplement implements BookDao{
	
	Book[] books;
	int index;
	
	public  BookDaoImplement() {
		books=new Book[50];
	
	}

	@Override
	public void saveBook(Book book) {
		books[index]=book;
		index++;
		
	}

	@Override
	public void listAllBook() {
		
		System.out.println("BookId\tBookName\tAuthor\tPublisher\tPrice");
		
		for(int i=0;i<index;i++)
		{
			books[i].showBookDetail();
		
		}
		
	}
	
	/*public Book findBook(int book_id){
		
		
		return book;
	}
	
	public void deleteBook(int book_id){
		
		
		
	}
	*/
}
