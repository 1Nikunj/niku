package org.capgemini.practice5;

public interface BookDao {

	public void saveBook(Book book);
	
	public void listAllBook();
	
	//public Book findBook(int book_id);
	
	//public void deleteBook(int book_id);
	
}
