package org.capgemini.practice2;

public class Example {

	static int count;
	int num;
	
	static
	{
		System.out.println("static var:"+count);
		System.out.println("static block");
	}
	
	{
		System.out.println("normal block");
	}
	
	Example(){
		System.out.println("constructor");
		
	}
	

	public static void main(String[] args) {
		
		Example ex=new Example();
		Example ex1=new Example();

	}

}
