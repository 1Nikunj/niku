package org.capgemini.practice2;

public class Rectangle extends Shape{

@Override
public void draw(){
		
		System.out.println("Rectangle class draw method");
		
	
}
}