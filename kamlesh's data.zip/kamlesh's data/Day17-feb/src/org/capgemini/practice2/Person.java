package org.capgemini.practice2;

public class Person {

}
