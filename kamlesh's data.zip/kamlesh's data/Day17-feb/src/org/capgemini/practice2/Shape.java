package org.capgemini.practice2;

public class Shape {

	public void draw(){
		
		System.out.println("shape class draw method");
	}
	
	
}
