package org.capgemini.practice2;



public class Circle extends Shape {

	
	@Override
	
	
	public void draw(){
		
		System.out.println("circle class draw method");
		
	}
}
