package org.capgemini.practice2;

import java.util.Scanner;

public class MainShape {

	public static void main(String[] args){
		   Scanner sc=new Scanner(System.in);
		   Shape shape;
		   
		   System.out.println("1.Circle");
		   System.out.println("2.Rectangle");
		   System.out.println("enter your option:");
		
		   int option=sc.nextInt();
		   
		   
		   if (option==1)
			   shape=new Circle();
		   else if (option==2)
			   shape=new Shape();
		   else
			   shape=new Shape();
		   
		   
		   shape.draw();
		
	}
}
