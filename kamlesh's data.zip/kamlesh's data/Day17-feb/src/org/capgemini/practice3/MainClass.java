package org.capgemini.practice3;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		Employee emp=null;
		 
		
		
		System.out.println("1.weekly salary:");
		System.out.println("2.monthly salary:");
		System.out.println("enter your choice:");
		
		int option=sc.nextInt();
		
		if(option==1)
			
			emp=new WeeklySalaryEmployee();
			//emp.calculateSalary();
			
		if(option==2)
			
			emp=new MonthlySalaryEmployee();
		    //emp.calculateSalary();
		
		emp.getEmployee();
		double sal= emp.calculateSalary();
		emp.printEmployee();
		    	
		System.out.println("salary: "+ sal);
		
		
	}

}
