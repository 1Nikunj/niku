package org.capgemini.practice3;
import java.util.Scanner;


public abstract class Employee {
	
	private int kin_id;
	private String first_name, last_name;
	
	
	
	public void getEmployee(){
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println(" enter kin id:");
		kin_id=sc.nextInt();
		
		System.out.println("enter first name:");
		first_name=sc.next();
		
		System.out.println("enter last name:");
		last_name=sc.next();
		
	}

	
	public void printEmployee(){
		
		System.out.println("Employee details:");
		System.out.println("Kin id:"+kin_id +  "first name:"+first_name +  "last name:"+last_name);
		
	}
	
	public abstract  double calculateSalary();
}
