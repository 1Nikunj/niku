package org.capgemini.practice3;
import java.util.Scanner;

public class WeeklySalaryEmployee  extends Employee {

	float no_of_hours;
	float wages_hour;
	
	

	@Override
	
	public double calculateSalary(){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of hours:");
		no_of_hours=sc.nextFloat();
		
		System.out.println("enter wages per hours:");
		wages_hour=sc.nextFloat();
		
		return no_of_hours*wages_hour;
		
	}
	
	
	
	
}
