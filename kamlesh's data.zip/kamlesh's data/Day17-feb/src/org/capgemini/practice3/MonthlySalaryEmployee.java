package org.capgemini.practice3;
import java.util.Scanner;

public class MonthlySalaryEmployee extends Employee {

	float no_of_days;
	double salary_day;
	
@Override
	
	public double calculateSalary(){
	
	Scanner sc=new Scanner(System.in);


	System.out.println("enter no of days:");
	no_of_days=sc.nextFloat();
	
	System.out.println("enter the salary per day:");
	salary_day=sc.nextDouble();
	
	return no_of_days*salary_day;
}
}