package org.capgemini.JdbcPractice;

import java.sql.*;

public class JdbcDemo {

	public static void main(String[] args) throws Exception {

		
			//Connection con=null;
			//Statement stmt=null;
		
// load driver class
		Class.forName("com.mysql.jdbc.Driver");
		
		System.out.println("connected to database");

//connect to database---connection established	
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdatabase","root","Pass1234");

//create statement for writing or accessing query
		Statement stmt=con.createStatement();
		 
			//String sql;
		 	//sql="select * from student";
		
//resultset for executing query	
		ResultSet rs=stmt.executeQuery("select * from student");
		
//iterating resultset		
		while(rs.next()){
			
			//System.out.println(rs.getString(3));
		
			System.out.println(rs.getString("FirstName"));
		
		}
//closing of statement,resultset,connection
		stmt.close();
		rs.close();
		con.close();
	
		}

}
