                                                                                                                                                                                                                                                       package com.flp.fms.service;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService {
	
	private IFilmDao filmDao=new FilmDaoImplForList();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguage();
	}

	@Override
	public List<Category> getCategory() {
		 return filmDao.getCategory();
				 }
	@Override
	public void addFilm(Film film) {
		
		film.setFim_id(generate_Film_Id());
		filmDao.addFilm(film);
		
	}
	
	
	public int generate_Film_Id(){
		
		int filmId=0;
		
		//Verify filmId has been Duplicated or not
		do{
			double fid=Math.random()*1000;
			filmId=(int)fid;
		}while(isDuplicateFilmId(filmId));
		
		
		return filmId;
	}
	//CHECKING WHETHER GENERATED FILM ID ALREADY EXISTS IN THE REPOSITORY
		public boolean isDuplicateFilmId(int filmId){
			
			boolean flag =false;
			
			//retrieving all the keys in the Film Repository
			Collection<Integer> keys = filmDao.getAllFilms().keySet();
			
			Iterator<Integer> itr = keys.iterator(); 
			while(itr.hasNext()){
				
				if(itr.next() == filmId){
					
					flag = true;
					break;
				}
			}
			
			return flag;
			
		}
	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}
	
	
	
	
	//RETRIEVING FILM FROM FILM REPOSITORY USING FILM ID
		@Override
		public Film searchFilm(int filmId) {
				
			return filmDao.searchFilm(filmId);
		}
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING LANGUAGE
		@Override
		public List<Film> searchFilm(Language language) {
			
			return filmDao.searchFilm(language);
		}
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING FILM TITLE
		@Override
		public Film searchFilm(String title) {
			
			return filmDao.searchFilm(title);
		}
		
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING FILM RATING
		@Override
		public List<Film> searchFilmByRating(int rating) {
			
			return filmDao.searchFilmByRating(rating);
		}
		
		
		//RETRIEVING FILM FROM FILM REPOSITORY USING ACTOR
		@Override
		public List<Film> searchFilm(Actor actor) {
			
			return filmDao.searchFilm(actor);
		}
		
		
		@Override
		public Film searchFilm(String title, Date releaseDate, int rating) {

			return filmDao.searchFilm(title, releaseDate, rating);
		}

		
		//REMOVING FILM USING FILM ID
		@Override
		public void removeFilm(int filmId) {
			
			filmDao.removeFilm(filmId);
		}

		//REMOVING FILM USING FILM TITLE
		@Override
		public void removeFilm(String title) {
			
			filmDao.removeFilm(title);
		}

		//REMOVING FILM USING RATING
		@Override
		public void removeFilmByRating(int rating) {
			
			filmDao.removeFilmByRating(rating);
		}

		@Override
		public void removeFilm(Actor actor) {
			
			filmDao.removeFilm(actor);
		}

		@Override
		public void updateFilm(Film film) {

			filmDao.updateFilm(film);	
		}

		
	}
