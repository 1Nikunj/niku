package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImplementation;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImpl;


public class CreateServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		IFilmService filmService=new IFilmServiceImpl();
		IActorService actorService=(IActorService) new IActorServiceImplementation();
		//IFilmDaoIml ser=new IFilmDaoIml();
		//List<Language>languages=ser.getOriginalLanguage();
		List<Actor> actors=actorService.getActorList();
		List<Language> languages=filmService.getLanguage();
		List<Category> categories=filmService.getCategory();
		out.print("<html>");
		out.print("<head>");
		
		out.println( "<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
		out.println( "<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
			out.println( "<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>");
		out.println( "<script type='text/javascript' src='script/Validate.js'></script>");
		out.println( "<link type='text/css' rel='stylesheet' href='css/mystyles.css'>");
		
		out.println("<script type='text/javascript' src='script/jquery-1.8.3.js'></script>"
		+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.js'></script>"
		+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.min.js'></script>"
		+ "<script type='text/javascript' src='script/dateSelector.js'></script>");
//		out.println("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
//		out.println("<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
//		out.println(" <script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>");
//		out.println( "<script type='text/javascript' src='../script/Validate.js'> </script>");
//		out.println(  "");
		out.println("<title>Film Details</title>");

		/*out.println( "<script>");
		out.println(  "  $(function() {");
		out.println(  "    $( '#datepicker').datepicker({  maxDate: '0', dateformat:'dd-mmm-yyyy'});");
		out.println( "  });");
		out.println(  "  </script>");

		out.println( "<script>");
		out.println(  "  $(function() {");
		out.println(  "  $( '#datepicker1').datepicker({dateformat:'dd-mmm-yyyy'});");
		out.println( "  });");
		out.println(  "  </script>");
		out.println(  "");
		out.print("</head>");*/
	
		out.print("<body>");
		out.print("<form name='CreateFilm1' method='post' action='AddFilm' >");
		out.print("<h1 align='center'> Film Details : </h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>Film Title</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='title' onmouseout='return validateTitle()'> </td>"
				+ "<div id='titleerr' ></div>"
				
				+ "</tr>");
		out.print("<tr>"
				+ "<td><label>Description</label></td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='desc' cols='25' onmouseout=' return validateDesc()'></textarea></td>"
				+ "<td><div id='descerr'></div><td>"
				);
		
		out.println("<tr>"
				+"<td><label>Release Date</label></td>"
				+"<td>:</td>"
				+"<td><input type='text' name='releasedate'  id ='datepicker'  size='20'>"
				+"</td>"
				+"</tr>");
		
		out.println("<tr>"
				+"<td>Rental Duration</td>"
				+"<td>:</td><td><input type='text' name='duration' id ='datepicker1' onmouseout=' return validateRentalDuration()'  size='20'></td>"
				+ "<td><div id='Rentalerr'></div><td>"
				+"</tr>");
		
		
		out.print("<tr>"
				+ "<td>Length Of Film</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='length' size='20' onmouseout='return validateLength()'></td>"
				+ "<td><div id='Durerr'></div><td>"
				+"</tr>");
		
		out.print("<tr><td>Original Language</td><td>:</td>"
				+ "<td><select name='orgLang'>");
		for(Language lang:languages)
		{
			out.print("<option value='"+lang.getLanguage_id()+"'>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
		}
	out.print("</select></td></tr>");
		out.print("<tr>"
				+ "<td>Replacement Cost</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='cost' size='20' onmouseout='return ValidateReplacementCost()'></td>"
				+ "<div id=' ReplacementCost' class='errMsg'> </div>"
				+ "</tr>");
	
		
		out.print("<tr>"
				+ "<td>Ratings</td>"
				+ "<td>:</td>"
				+ "<td><select name='rating' onchange='return isratingSelected()'>"
				//+ "<option value=''>Select Rating</option>"
				+ "<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>	"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"
				+ "</select></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td><label>Special Features:</td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='features' cols='25'  onmouseout='return ValidateSpecialFeature()'></textarea></td>"
				+ "<td><div id='featureeerr' class='errMsg'> </div></td> "
				+ "</tr>");
	
	out.print("<tr><td>Category</td><td>:</td>"
			+ "<td><select name='category'>");
	for(Category category1:categories){
		out.print("<option value='"+category1.getCategory_id()+"'>" +category1.getCategory_name()+"</option>");
	}
   out.print("</select></td></tr>");
   

	out.print("<tr><td>Actor</td><td>:</td>"
			+ "<td><select name='actor' multiple=''>");
	for(Actor actor1:actors){
		out.print("<option value='"+actor1.getActor_Id()+"'>"+actor1.getActor_Id()+" "+actor1.getActor_FirstName()+" "+actor1.getActor_LastName()+"</option>");
	}
	out.print("</select></td></tr>");
	
	out.print("<tr><td>Other Language</td><td>:</td>"
				+ "<td><select name='othrlang' multiple='' class='ui fluid dropdown'>");
		for(Language lang:languages){
			out.print("<option value='"+lang.getLanguage_id()+"'>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
		}
	out.print("</select></td></tr>");
	
	out.print("<tr><td></td>"
			+ "<td><input type='submit' value='Submit'></td>"
			+ "<td><input type='reset' value='clear'</td>"
			+ "</tr>");	
	
	out.print("</frame");
	out.print("</table");
	out.print("</body");
		out.print("</html");
		
		

	}
	
	
	
	}
