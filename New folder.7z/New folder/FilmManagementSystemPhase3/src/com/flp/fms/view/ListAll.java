package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImpl;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

/**
 * Servlet implementation class ListAll
 */
public class ListAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ListAll() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*IFilmService filmservice=new iFilmServiceImpl();
		ArrayList<Film> films=filmservice.getAllFilms();
	  Actor actor = new Actor();
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>ListAll Film</head>"
				+ "<body>"
				+ "<div style='margin-left:500px;'> Welcome! </div>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Employee Id</th>"
				+ "<th>tittle</th>"
				+ "<th>description</th>"
				+ "<th>releaseYear</th>"
				+ "<th>retalDuration</th>"
				+ "<th>length</th>"
				+ "<th>originalLanguage</th>"
				+ "<th>replacementCost</th>"
				+ "<th>ratings</th>"
				+ "<th>SpecialFeature</th>"
				+ "<th>Category</th>"
				+ "<th>ActorName</th>"
				+ "<th>ActorLastName</th>"
				+ "</tr>");
		
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilm_id()+"</td>");
				out.println("<td>"+film.getTittle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getRetalDuration()+"</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getOriginalLanguage().getLanguage_name()+"</td>");
				out.println("<td>"+film.getReplacementCost()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getSpecialFeature()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_name()+"</td>");
				
				List<Actor> actors = new ArrayList<>();
				actors=film.getActors();
				out.println("<td>");
				for(Actor act:actors)
					out.println(act.getActor_FirstName()+" "+act.getActor_LastName());
					out.println("</td>");
				
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
				
				
	}
*/
		

		PrintWriter out=response.getWriter();
		
		/*out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		out.print("<body>");
		out.print("Add");
		out.print("</body>");*/
		
		IFilmServiceImpl filmservice=new IFilmServiceImpl();
		List<Film> film=(List<Film>) filmservice.getAllFilms();
	
		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		out.println("<body>"
				+ "<h2 align='center'>List Of Films</h2>"
				+ "<table border=2px>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Original Language</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Category</th>"
				+ "<th>Languages</th>"
				+ "<th>Actors</th>"
				+ "</tr>");
		for(Film film1:film){
			List<Language> languages=film1.getLanguages();
			
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguage_name()+",";
			}
			System.out.println(film1.getLanguages());
			List<Actor> actors=film1.getActors();
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getActor_FirstName()+" "+actor.getActor_LastName()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_id()+"</td>");
			out.println("<td>"+film1.getTittle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getReleaseYear()+"</td>");
			out.println("<td>"+film1.getRetalDuration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguage_name()+"</td>");
			out.println("<td>"+film1.getReplacementCost()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecialFeature()+"</td>");
			out.println("<td>"+film1.getCategory().getCategory_name()+"</td>");
			out.println("<td>"+langs+"</td>");
			/*List<Actor> actors2 = new ArrayList<>();
			actors=film1.getActors();
			out.println("<td>");
			for(Actor act:actors)
				out.println(act.getActor_FirstName()+" "+act.getActor_LastName());
				out.println("</td>");
			
			out.println("</tr>");*/
			out.println("<td>"+actors1+"</td>");
			//out.println("</tr>");
		}
			out.println("</table></body>");
	    
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
