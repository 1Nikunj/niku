package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;


import com.flp.fms.dao.IFilmDao;
import com.flp.fms.dao.IFilmDaoIml;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class IFilmServiceImpl  implements IFilmService{
	IFilmDao filmDao=new IFilmDaoIml();
	@Override
	public List<Language> getLanguage() {
		
		return filmDao.getOriginalLanguage() ;
	}

	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}

	@Override
	public void addFilm(Film film) {

	    //film.setFilm_id(film_id);
		filmDao.addFilm(film);
		
	}


	@Override
	public ArrayList<Film> getAllFilms() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilms();
	}


	public Boolean deleteFilm(int filmid) {
		// TODO Auto-generated method stub
		return filmDao.deleteFilm(filmid);
	}


	public ArrayList<Film> searchFilm(Film film) {
		
		return filmDao.searchFilm(film);
	}

	
	public int updateFilm(int id,Film film) {
		return filmDao.updateFilm(id,film);
		
		
	}

	public Film getSearchFilmByID(int id) {
		// TODO Auto-generated method stub
		return filmDao.getSearchFilmByID(id);
	}

}
