package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


public interface IFilmService {
	public List<Language> getLanguage();

	public List<Category> getCategory();

	void addFilm(Film film);

	public ArrayList<Film> getAllFilms();
	//public Map<Integer, Film> getAllFilms();
//	public void deleteFilm(int filmid);
	//public Map<Integer, Film> searchFilms();
	public Boolean deleteFilm(int filmid);
	ArrayList<Film> searchFilm(Film film);
	public int updateFilm(int id,Film film);
}
