package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IActorImpl;
import com.flp.fms.domain.Actor;


public class IActorServiceImplementation implements IActorService{
	IActorDao actorDao=new IActorImpl();
	@Override
	public List<Actor> addActor() {
		
		return actorDao.addActor();
	}

	@Override
	public List<Actor> getActorList() {
		
		return actorDao.getActorList();
	}

}
