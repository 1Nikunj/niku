package com.flp.fms.domain;

public class Language {
	private int Language_id;
	private String Language_name;
	
	public Language(){}
	
	public Language(int language_id, String language_name) {
		super();
		Language_id = language_id;
		Language_name = language_name;
	}
	public int getLanguage_id() {
		return Language_id;
	}
	public void setLanguage_id(int language_id) {
		Language_id = language_id;
	}
	public String getLanguage_name() {
		return Language_name;
	}
	public void setLanguage_name(String language_name) {
		Language_name = language_name;
	}
	@Override
	public String toString() {
		return "Language [Language_id=" + Language_id + ", Language_name=" + Language_name + "]";
	}
	
}
